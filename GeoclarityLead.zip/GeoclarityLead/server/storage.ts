import { 
  users, type User, type InsertUser,
  links, type Link, type InsertLink,
  conversations, type Conversation, type InsertConversation,
  messages, type Message, type InsertMessage,
  knowledgeBase, type KnowledgeBase, type InsertKnowledgeBase
} from "@shared/schema";

// Storage interface
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Link operations
  createLink(link: InsertLink): Promise<Link>;
  getLinkByShortId(shortId: string): Promise<Link | undefined>;
  getLinkById(id: number): Promise<Link | undefined>;
  getLinksByUserId(userId: number): Promise<Link[]>;
  incrementLinkVisits(id: number): Promise<void>;
  updateLink(id: number, link: Partial<InsertLink>): Promise<Link | undefined>;
  deleteLink(id: number): Promise<boolean>;

  // Conversation operations
  createConversation(conversation: InsertConversation): Promise<Conversation>;
  getConversationById(id: number): Promise<Conversation | undefined>;
  getConversationsByLinkId(linkId: number): Promise<Conversation[]>;
  getRecentConversations(limit: number): Promise<Conversation[]>;
  updateConversation(id: number, data: Partial<Conversation>): Promise<Conversation | undefined>;

  // Message operations
  createMessage(message: InsertMessage): Promise<Message>;
  getMessagesByConversationId(conversationId: number): Promise<Message[]>;

  // Knowledge base operations
  addKnowledgeItem(item: InsertKnowledgeBase): Promise<KnowledgeBase>;
  getKnowledgeBaseById(id: number): Promise<KnowledgeBase | undefined>;
  getKnowledgeBaseByUserId(userId: number): Promise<KnowledgeBase[]>;
  searchKnowledgeBase(userId: number, query: string): Promise<KnowledgeBase[]>;
  deleteKnowledgeItem(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private links: Map<number, Link>;
  private conversations: Map<number, Conversation>;
  private messages: Map<number, Message>;
  private knowledgeBase: Map<number, KnowledgeBase>;
  
  private userId: number = 1;
  private linkId: number = 1;
  private conversationId: number = 1;
  private messageId: number = 1;
  private knowledgeItemId: number = 1;

  constructor() {
    this.users = new Map();
    this.links = new Map();
    this.conversations = new Map();
    this.messages = new Map();
    this.knowledgeBase = new Map();
    
    // Initialize with a demo user
    this.createUser({
      username: "demo",
      password: "demo123",
      businessName: "Example Company",
      email: "demo@example.com",
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Link operations
  async createLink(insertLink: InsertLink): Promise<Link> {
    const id = this.linkId++;
    const shortId = Math.random().toString(36).substring(2, 8);
    const timestamp = new Date();
    const link: Link = { 
      ...insertLink, 
      id, 
      shortId, 
      createdAt: timestamp, 
      visits: 0 
    };
    this.links.set(id, link);
    return link;
  }

  async getLinkByShortId(shortId: string): Promise<Link | undefined> {
    return Array.from(this.links.values()).find(
      (link) => link.shortId === shortId,
    );
  }

  async getLinkById(id: number): Promise<Link | undefined> {
    return this.links.get(id);
  }

  async getLinksByUserId(userId: number): Promise<Link[]> {
    return Array.from(this.links.values()).filter(
      (link) => link.userId === userId,
    );
  }

  async incrementLinkVisits(id: number): Promise<void> {
    const link = this.links.get(id);
    if (link) {
      link.visits += 1;
      this.links.set(id, link);
    }
  }

  async updateLink(id: number, data: Partial<InsertLink>): Promise<Link | undefined> {
    const link = this.links.get(id);
    if (!link) return undefined;
    
    const updatedLink: Link = { ...link, ...data };
    this.links.set(id, updatedLink);
    return updatedLink;
  }

  async deleteLink(id: number): Promise<boolean> {
    return this.links.delete(id);
  }

  // Conversation operations
  async createConversation(insertConversation: InsertConversation): Promise<Conversation> {
    const id = this.conversationId++;
    const startedAt = new Date();
    const conversation: Conversation = { 
      ...insertConversation, 
      id, 
      startedAt,
      endedAt: null,
      intent: null,
      qualified: null,
    };
    this.conversations.set(id, conversation);
    return conversation;
  }

  async getConversationById(id: number): Promise<Conversation | undefined> {
    return this.conversations.get(id);
  }

  async getConversationsByLinkId(linkId: number): Promise<Conversation[]> {
    return Array.from(this.conversations.values()).filter(
      (conversation) => conversation.linkId === linkId,
    );
  }

  async getRecentConversations(limit: number): Promise<Conversation[]> {
    return Array.from(this.conversations.values())
      .sort((a, b) => new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime())
      .slice(0, limit);
  }

  async updateConversation(id: number, data: Partial<Conversation>): Promise<Conversation | undefined> {
    const conversation = this.conversations.get(id);
    if (!conversation) return undefined;
    
    const updatedConversation: Conversation = { ...conversation, ...data };
    this.conversations.set(id, updatedConversation);
    return updatedConversation;
  }

  // Message operations
  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.messageId++;
    const timestamp = new Date();
    const message: Message = { ...insertMessage, id, timestamp };
    this.messages.set(id, message);
    return message;
  }

  async getMessagesByConversationId(conversationId: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter((message) => message.conversationId === conversationId)
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  }

  // Knowledge base operations
  async addKnowledgeItem(insertItem: InsertKnowledgeBase): Promise<KnowledgeBase> {
    const id = this.knowledgeItemId++;
    const item: KnowledgeBase = { ...insertItem, id };
    this.knowledgeBase.set(id, item);
    return item;
  }

  async getKnowledgeBaseById(id: number): Promise<KnowledgeBase | undefined> {
    return this.knowledgeBase.get(id);
  }

  async getKnowledgeBaseByUserId(userId: number): Promise<KnowledgeBase[]> {
    return Array.from(this.knowledgeBase.values()).filter(
      (item) => item.userId === userId,
    );
  }

  async searchKnowledgeBase(userId: number, query: string): Promise<KnowledgeBase[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.knowledgeBase.values())
      .filter(
        (item) => item.userId === userId && item.content.toLowerCase().includes(lowerQuery)
      );
  }

  async deleteKnowledgeItem(id: number): Promise<boolean> {
    return this.knowledgeBase.delete(id);
  }
}

export const storage = new MemStorage();
