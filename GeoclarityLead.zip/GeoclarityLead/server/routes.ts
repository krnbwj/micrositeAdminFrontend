import express, { type Request, Response } from "express";
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { processUserMessage, processKnowledgeContent } from "./openai";
import { z } from "zod";
import { 
  insertUserSchema, 
  insertLinkSchema, 
  insertConversationSchema,
  insertMessageSchema,
  insertKnowledgeBaseSchema
} from "@shared/schema";
import session from "express-session";
import MemoryStore from "memorystore";

const SessionStore = MemoryStore(session);

// Schema for authentication
const loginSchema = z.object({
  username: z.string().min(1),
  password: z.string().min(1),
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up session management
  app.use(
    session({
      cookie: { maxAge: 86400000 }, // 24 hours
      store: new SessionStore({
        checkPeriod: 86400000 // prune expired entries every 24h
      }),
      resave: false,
      saveUninitialized: false,
      secret: process.env.SESSION_SECRET || 'leadproxy-secret-key'
    })
  );

  // Middleware to check authentication
  const requireAuth = (req: Request, res: Response, next: Function) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: 'Unauthorized' });
    }
    next();
  };

  // Authentication routes
  app.post('/api/auth/login', async (req: Request, res: Response) => {
    try {
      const { username, password } = loginSchema.parse(req.body);
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }
      
      req.session.userId = user.id;
      res.json({ 
        id: user.id, 
        username: user.username,
        businessName: user.businessName,
        email: user.email
      });
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post('/api/auth/register', async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if username exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: 'Username already exists' });
      }
      
      const user = await storage.createUser(userData);
      req.session.userId = user.id;
      
      res.status(201).json({ 
        id: user.id, 
        username: user.username,
        businessName: user.businessName,
        email: user.email
      });
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get('/api/auth/me', async (req: Request, res: Response) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    
    const user = await storage.getUser(req.session.userId);
    if (!user) {
      req.session.destroy(() => {});
      return res.status(401).json({ message: 'User not found' });
    }
    
    res.json({ 
      id: user.id, 
      username: user.username,
      businessName: user.businessName,
      email: user.email
    });
  });

  app.post('/api/auth/logout', (req: Request, res: Response) => {
    req.session.destroy(() => {
      res.status(200).json({ message: 'Logged out successfully' });
    });
  });

  // Links routes
  app.post('/api/links', requireAuth, async (req: Request, res: Response) => {
    try {
      const linkData = insertLinkSchema.parse({
        ...req.body,
        userId: req.session.userId
      });
      
      const link = await storage.createLink(linkData);
      res.status(201).json(link);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get('/api/links', requireAuth, async (req: Request, res: Response) => {
    const links = await storage.getLinksByUserId(req.session.userId);
    res.json(links);
  });

  app.get('/api/links/:id', requireAuth, async (req: Request, res: Response) => {
    const link = await storage.getLinkById(Number(req.params.id));
    
    if (!link) {
      return res.status(404).json({ message: 'Link not found' });
    }
    
    if (link.userId !== req.session.userId) {
      return res.status(403).json({ message: 'Forbidden' });
    }
    
    res.json(link);
  });

  app.patch('/api/links/:id', requireAuth, async (req: Request, res: Response) => {
    const link = await storage.getLinkById(Number(req.params.id));
    
    if (!link) {
      return res.status(404).json({ message: 'Link not found' });
    }
    
    if (link.userId !== req.session.userId) {
      return res.status(403).json({ message: 'Forbidden' });
    }
    
    try {
      const updateData = req.body;
      const updatedLink = await storage.updateLink(link.id, updateData);
      res.json(updatedLink);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete('/api/links/:id', requireAuth, async (req: Request, res: Response) => {
    const link = await storage.getLinkById(Number(req.params.id));
    
    if (!link) {
      return res.status(404).json({ message: 'Link not found' });
    }
    
    if (link.userId !== req.session.userId) {
      return res.status(403).json({ message: 'Forbidden' });
    }
    
    await storage.deleteLink(link.id);
    res.status(204).end();
  });

  // Proxy link redirect route
  app.get('/r/:shortId', async (req: Request, res: Response) => {
    const { shortId } = req.params;
    const link = await storage.getLinkByShortId(shortId);
    
    if (!link) {
      return res.status(404).send('Link not found');
    }
    
    // Increment visits count
    await storage.incrementLinkVisits(link.id);
    
    // If AI conversation is disabled, redirect immediately
    if (!link.enableAi) {
      const redirectUrl = link.utmParams 
        ? `${link.targetUrl}${link.targetUrl.includes('?') ? '&' : '?'}${link.utmParams}`
        : link.targetUrl;
      
      return res.redirect(redirectUrl);
    }
    
    // Otherwise, serve the conversation interface
    res.send(`
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Connecting...</title>
        <script>
          window.LINK_DATA = ${JSON.stringify({
            id: link.id,
            shortId: link.shortId,
            targetUrl: link.targetUrl,
            utmParams: link.utmParams
          })};
        </script>
        <script src="/conversation.js" defer></script>
      </head>
      <body>
        <div id="conversation-root"></div>
      </body>
      </html>
    `);
  });

  // Conversation API routes
  app.post('/api/conversations', async (req: Request, res: Response) => {
    try {
      const conversationData = insertConversationSchema.parse(req.body);
      
      // Verify link exists
      const link = await storage.getLinkById(conversationData.linkId);
      if (!link) {
        return res.status(404).json({ message: 'Link not found' });
      }
      
      const conversation = await storage.createConversation(conversationData);
      res.status(201).json(conversation);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get('/api/conversations/:id', requireAuth, async (req: Request, res: Response) => {
    const conversation = await storage.getConversationById(Number(req.params.id));
    
    if (!conversation) {
      return res.status(404).json({ message: 'Conversation not found' });
    }
    
    // Verify user owns the link associated with this conversation
    const link = await storage.getLinkById(conversation.linkId);
    if (link?.userId !== req.session.userId) {
      return res.status(403).json({ message: 'Forbidden' });
    }
    
    // Get messages for this conversation
    const messages = await storage.getMessagesByConversationId(conversation.id);
    
    res.json({
      conversation,
      messages
    });
  });

  app.get('/api/conversations', requireAuth, async (req: Request, res: Response) => {
    const userId = req.session.userId;
    const links = await storage.getLinksByUserId(userId);
    const linkIds = links.map(link => link.id);
    
    const allConversations = [];
    for (const linkId of linkIds) {
      const conversations = await storage.getConversationsByLinkId(linkId);
      allConversations.push(...conversations);
    }
    
    // Sort by most recent first
    allConversations.sort((a, b) => 
      new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime()
    );
    
    res.json(allConversations);
  });

  // Message API routes
  app.post('/api/messages', async (req: Request, res: Response) => {
    try {
      const messageData = insertMessageSchema.parse(req.body);
      
      // Verify conversation exists
      const conversation = await storage.getConversationById(messageData.conversationId);
      if (!conversation) {
        return res.status(404).json({ message: 'Conversation not found' });
      }
      
      // Save the user message
      const message = await storage.createMessage(messageData);
      
      // Get the link and user for context
      const link = await storage.getLinkById(conversation.linkId);
      const user = link ? await storage.getUser(link.userId) : undefined;
      
      // Get knowledge base content if AI is enabled and knowledge IDs are selected
      let knowledgeContent: string[] = [];
      if (link?.enableAi && link?.selectedKnowledgeIds && link.selectedKnowledgeIds.length > 0) {
        // Get all selected knowledge base items
        const knowledgeItems = await Promise.all(
          link.selectedKnowledgeIds.map(id => storage.getKnowledgeBaseById(id))
        );
        
        // Extract content from valid items
        knowledgeContent = knowledgeItems
          .filter(item => item !== undefined)
          .map(item => item!.content);
      }
      
      // Process with AI and get response
      const businessContext = user?.businessName || "";
      const aiResponse = await processUserMessage(messageData.content, businessContext, knowledgeContent);
      
      // Save the AI response
      const responseMessage = await storage.createMessage({
        conversationId: messageData.conversationId,
        content: aiResponse.response,
        role: 'assistant'
      });
      
      // Update conversation with intent information if this is new
      if (!conversation.intent) {
        await storage.updateConversation(conversation.id, {
          intent: aiResponse.intent,
          qualified: aiResponse.qualified
        });
      }
      
      res.json({
        userMessage: message,
        aiMessage: responseMessage,
        intent: aiResponse.intent,
        qualified: aiResponse.qualified
      });
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  // Knowledge base API routes
  app.post('/api/knowledge', requireAuth, async (req: Request, res: Response) => {
    try {
      const knowledgeData = insertKnowledgeBaseSchema.parse({
        ...req.body,
        userId: req.session.userId
      });
      
      // Process content with AI to create chunks/embeddings
      const processedChunks = await processKnowledgeContent(knowledgeData.content);
      
      // Save each chunk as a separate knowledge item
      const savedItems = [];
      for (const chunk of processedChunks) {
        const item = await storage.addKnowledgeItem({
          ...knowledgeData,
          content: chunk
        });
        savedItems.push(item);
      }
      
      res.status(201).json(savedItems);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get('/api/knowledge', requireAuth, async (req: Request, res: Response) => {
    const items = await storage.getKnowledgeBaseByUserId(req.session.userId);
    res.json(items);
  });

  app.delete('/api/knowledge/:id', requireAuth, async (req: Request, res: Response) => {
    const id = Number(req.params.id);
    const item = await storage.getKnowledgeBaseByUserId(req.session.userId)
      .then(items => items.find(item => item.id === id));
    
    if (!item) {
      return res.status(404).json({ message: 'Knowledge item not found' });
    }
    
    await storage.deleteKnowledgeItem(id);
    res.status(204).end();
  });

  // Dashboard stats API
  app.get('/api/stats', requireAuth, async (req: Request, res: Response) => {
    const userId = req.session.userId;
    
    // Get all user links
    const links = await storage.getLinksByUserId(userId);
    
    // Collect conversations for all links
    let totalConversations = 0;
    let totalVisits = 0;
    
    const intentCounts = {
      NAVIGATIONAL: 0,
      TRANSACTIONAL: 0,
      INFORMATIONAL: 0
    };
    
    const qualifiedLeads = {
      count: 0,
      total: 0
    };
    
    for (const link of links) {
      totalVisits += link.visits;
      
      const conversations = await storage.getConversationsByLinkId(link.id);
      totalConversations += conversations.length;
      
      for (const conversation of conversations) {
        if (conversation.intent && intentCounts[conversation.intent] !== undefined) {
          intentCounts[conversation.intent]++;
        }
        
        if (conversation.qualified !== null) {
          qualifiedLeads.total++;
          if (conversation.qualified) {
            qualifiedLeads.count++;
          }
        }
      }
    }
    
    // Calculate conversion rate
    const conversionRate = qualifiedLeads.total > 0 
      ? (qualifiedLeads.count / qualifiedLeads.total) * 100 
      : 0;
    
    res.json({
      totalLinks: links.length,
      totalVisits,
      totalConversations,
      intentDistribution: intentCounts,
      conversionRate: parseFloat(conversionRate.toFixed(1))
    });
  });

  // Recent links and conversations for dashboard
  app.get('/api/dashboard', requireAuth, async (req: Request, res: Response) => {
    const userId = req.session.userId;
    
    // Get recent links
    const allLinks = await storage.getLinksByUserId(userId);
    const recentLinks = allLinks
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 5);
    
    // Get recent conversations
    const conversationsWithDetails = [];
    const allLinkIds = allLinks.map(link => link.id);
    
    for (const linkId of allLinkIds) {
      const linkConversations = await storage.getConversationsByLinkId(linkId);
      
      for (const conversation of linkConversations) {
        const messages = await storage.getMessagesByConversationId(conversation.id);
        const link = allLinks.find(l => l.id === linkId);
        
        conversationsWithDetails.push({
          ...conversation,
          link,
          messages: messages.slice(0, 3) // Just get the first few messages
        });
      }
    }
    
    // Sort and limit conversations
    const recentConversations = conversationsWithDetails
      .sort((a, b) => new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime())
      .slice(0, 5);
    
    res.json({
      recentLinks,
      recentConversations
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}
