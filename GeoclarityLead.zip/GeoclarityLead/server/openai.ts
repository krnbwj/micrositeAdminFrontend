import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || "sk-dummy-key-for-development" 
});

/**
 * Process a user message and generate a response based on context
 */
export async function processUserMessage(
  message: string, 
  businessContext: string = "", 
  knowledgeBaseContent: string[] = []
): Promise<{
  response: string;
  intent: string;
  qualified: boolean;
}> {
  try {
    // If there's an OpenAI API error, use a fallback response
    if (!process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY === "sk-dummy-key-for-development") {
      console.warn("No valid OpenAI API key found, using fallback response");
      return generateFallbackResponse(message);
    }
    
    // Construct knowledge base context if provided
    let knowledgeBaseText = "";
    if (knowledgeBaseContent && knowledgeBaseContent.length > 0) {
      knowledgeBaseText = "\n\nUse the following knowledge base content to answer user questions:\n" + 
        knowledgeBaseContent.join("\n\n");
    }
    
    // Construct system prompt with business context and knowledge base
    const systemPrompt = `You are an AI assistant${businessContext ? ` for ${businessContext}` : ''}. 
Your goal is to help qualify leads and provide valuable information.

Classify the user's intent as one of:
- NAVIGATIONAL (looking to go somewhere)
- TRANSACTIONAL (wanting to buy/transact)
- INFORMATIONAL (seeking information)

Also determine if this is a qualified lead based on:
- Their level of interest
- Specificity of their questions
- Mention of business needs, budgets, timelines, or requirements
- Indication they are in a decision-making role

${knowledgeBaseText}

Respond in JSON format with 3 fields:
{"intent": "INTENT_TYPE", "qualified": true/false, "response": "your helpful response to the user"}`;

    const completion = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: message }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7
    });

    // Ensure we have content to parse
    if (!completion.choices[0].message.content) {
      throw new Error("Empty response from OpenAI API");
    }
    const result = JSON.parse(completion.choices[0].message.content);
    
    return {
      response: result.response,
      intent: result.intent,
      qualified: result.qualified
    };
  } catch (error: any) {
    console.error("OpenAI API error:", error);
    
    // Check if it's a quota error
    if (error?.code === 'insufficient_quota') {
      return {
        response: "I apologize, but our AI service is currently experiencing high demand. Please contact us directly through our website or try again later.",
        intent: "ERROR",
        qualified: true // Mark as qualified when API fails to ensure lead capture
      };
    }
    
    return {
      response: "I apologize, but I'm having trouble processing your request right now. Please try again later.",
      intent: "ERROR",
      qualified: false
    };
  }
}

/**
 * Generate a fallback response when OpenAI API is unavailable
 */
function generateFallbackResponse(message: string): {
  response: string;
  intent: string;
  qualified: boolean;
} {
  // Simple rule-based fallback that tries to detect intent and qualification
  const lowerMessage = message.toLowerCase();
  
  // Check for transactional intent
  const transactionalKeywords = ['buy', 'purchase', 'cost', 'price', 'quote', 'package', 'deal', 'subscribe'];
  const isTransactional = transactionalKeywords.some(keyword => lowerMessage.includes(keyword));
  
  // Check for navigational intent
  const navigationalKeywords = ['where', 'location', 'find', 'go to', 'directions', 'address'];
  const isNavigational = navigationalKeywords.some(keyword => lowerMessage.includes(keyword));
  
  // Determine intent
  let intent = "INFORMATIONAL";
  if (isTransactional) intent = "TRANSACTIONAL";
  if (isNavigational) intent = "NAVIGATIONAL";
  
  // Determine qualification (simple heuristic)
  const qualificationKeywords = ['interested', 'need', 'looking for', 'want to', 'require', 'help', 'urgent'];
  const isQualified = qualificationKeywords.some(keyword => lowerMessage.includes(keyword)) || isTransactional;
  
  // Generate simple response
  let response = "I'm here to help answer any questions you might have about our services. Could you tell me more about what you're looking for?";
  
  if (isTransactional) {
    response = "Thank you for your interest in our products/services. I'd be happy to discuss pricing and options. Could you please share what specific requirements you have?";
  } else if (isNavigational) {
    response = "I'd be happy to help you find what you're looking for. Could you please provide more details about what you need assistance with?";
  }
  
  return {
    response,
    intent,
    qualified: isQualified
  };
}

/**
 * Process knowledge base content to create embeddings and chunks
 */
export async function processKnowledgeContent(content: string): Promise<string[]> {
  // In a real implementation, this would create embeddings and store them
  // For this MVP, we'll just split content into paragraphs
  const paragraphs = content.split(/\n\s*\n/).filter(p => p.trim().length > 0);
  return paragraphs;
}

/**
 * Search knowledge base using semantic similarity
 */
export async function searchKnowledgeBase(query: string, knowledgeItems: string[]): Promise<string[]> {
  // In a real implementation, this would use vector similarity search
  // For this MVP, we'll use simple keyword matching
  const lowerQuery = query.toLowerCase();
  return knowledgeItems.filter(item => item.toLowerCase().includes(lowerQuery));
}
