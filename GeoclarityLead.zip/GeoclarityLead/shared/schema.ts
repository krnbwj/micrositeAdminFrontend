import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model for authentication
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  businessName: text("business_name"),
  email: text("email"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  businessName: true,
  email: true,
});

// Proxy links model
export const links = pgTable("links", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  shortId: text("short_id").notNull().unique(),
  name: text("name").notNull(),
  targetUrl: text("target_url").notNull(),
  utmParams: text("utm_params"),
  enableAi: boolean("enable_ai").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  visits: integer("visits").default(0),
  selectedKnowledgeIds: jsonb("selected_knowledge_ids").$type<number[]>(), // Store array of knowledge base IDs
});

export const insertLinkSchema = createInsertSchema(links).pick({
  userId: true,
  name: true,
  targetUrl: true,
  utmParams: true,
  enableAi: true,
}).extend({
  selectedKnowledgeIds: z.array(z.number()).optional(),
});

// Conversations model
export const conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  linkId: integer("link_id").notNull(),
  sessionId: text("session_id").notNull(),
  visitorIp: text("visitor_ip"),
  startedAt: timestamp("started_at").defaultNow(),
  endedAt: timestamp("ended_at"),
  intent: text("intent"),
  qualified: boolean("qualified"),
});

export const insertConversationSchema = createInsertSchema(conversations).pick({
  linkId: true,
  sessionId: true,
  visitorIp: true,
});

// Messages within conversations
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").notNull(),
  content: text("content").notNull(),
  role: text("role").notNull(), // 'user' or 'assistant'
  timestamp: timestamp("timestamp").defaultNow(),
});

export const insertMessageSchema = createInsertSchema(messages).pick({
  conversationId: true,
  content: true,
  role: true,
});

// Knowledge base document chunks for vector retrieval
export const knowledgeBase = pgTable("knowledge_base", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  content: text("content").notNull(),
  source: text("source").notNull(), // e.g., 'website', 'pdf', 'manual'
  metadata: jsonb("metadata"),
});

export const insertKnowledgeBaseSchema = createInsertSchema(knowledgeBase).pick({
  userId: true,
  content: true,
  source: true,
  metadata: true,
});

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Link = typeof links.$inferSelect;
export type InsertLink = z.infer<typeof insertLinkSchema>;

export type Conversation = typeof conversations.$inferSelect;
export type InsertConversation = z.infer<typeof insertConversationSchema>;

export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;

export type KnowledgeBase = typeof knowledgeBase.$inferSelect;
export type InsertKnowledgeBase = z.infer<typeof insertKnowledgeBaseSchema>;
