import { apiRequest } from "./queryClient";

/**
 * Creates a new conversation for a link
 */
export async function createConversation(data: {
  linkId: number;
  sessionId: string;
  visitorIp?: string;
}) {
  const response = await apiRequest("POST", "/api/conversations", data);
  return response.json();
}

/**
 * Sends a message in a conversation
 */
export async function sendMessage(data: {
  conversationId: number;
  content: string;
  role: 'user' | 'assistant';
}) {
  const response = await apiRequest("POST", "/api/messages", data);
  return response.json();
}

/**
 * Gets a single conversation with its messages
 */
export async function getConversation(id: number) {
  const response = await fetch(`/api/conversations/${id}`, {
    credentials: "include",
  });
  
  if (!response.ok) {
    throw new Error(`Failed to fetch conversation: ${response.statusText}`);
  }
  
  return response.json();
}

/**
 * Gets the intent color based on the intent value
 */
export function getIntentColor(intent: string | null): string {
  switch (intent) {
    case 'NAVIGATIONAL':
      return 'primary';
    case 'TRANSACTIONAL':
      return 'warning';
    case 'INFORMATIONAL':
      return 'success';
    default:
      return 'secondary';
  }
}

/**
 * Formats the intent for display
 */
export function formatIntent(intent: string | null): string {
  if (!intent) return 'Unknown Intent';
  
  return intent.charAt(0) + intent.slice(1).toLowerCase() + ' Intent';
}
