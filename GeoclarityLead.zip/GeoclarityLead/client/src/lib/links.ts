import { apiRequest } from "./queryClient";
import { Link } from "@shared/schema";

/**
 * Creates a new proxy link
 */
export async function createLink(data: {
  name: string;
  targetUrl: string;
  utmParams?: string;
  enableAi: boolean;
}): Promise<Link> {
  const response = await apiRequest("POST", "/api/links", data);
  return response.json();
}

/**
 * Updates an existing proxy link
 */
export async function updateLink(
  id: number,
  data: {
    name?: string;
    targetUrl?: string;
    utmParams?: string;
    enableAi?: boolean;
  }
): Promise<Link> {
  const response = await apiRequest("PATCH", `/api/links/${id}`, data);
  return response.json();
}

/**
 * Deletes a proxy link
 */
export async function deleteLink(id: number): Promise<void> {
  await apiRequest("DELETE", `/api/links/${id}`);
}

/**
 * Formats a link URL for display or copy
 */
export function formatLinkUrl(shortId: string): string {
  return `${window.location.origin}/r/${shortId}`;
}
