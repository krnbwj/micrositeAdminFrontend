import { apiRequest } from "./queryClient";
import { KnowledgeBase } from "@shared/schema";

/**
 * Adds knowledge content to the knowledge base
 */
export async function addKnowledgeContent(data: {
  content: string;
  source: string;
  metadata?: Record<string, any>;
}): Promise<KnowledgeBase[]> {
  const response = await apiRequest("POST", "/api/knowledge", data);
  return response.json();
}

/**
 * Gets all knowledge base items for the current user
 */
export async function getKnowledgeBase(): Promise<KnowledgeBase[]> {
  const response = await fetch("/api/knowledge", {
    credentials: "include",
  });
  
  if (!response.ok) {
    throw new Error(`Failed to fetch knowledge base: ${response.statusText}`);
  }
  
  return response.json();
}

/**
 * Deletes a knowledge base item
 */
export async function deleteKnowledgeItem(id: number): Promise<void> {
  await apiRequest("DELETE", `/api/knowledge/${id}`);
}

/**
 * Gets source icon based on source type
 */
export function getSourceIcon(source: string): string {
  switch (source.toLowerCase()) {
    case 'website':
      return 'globe';
    case 'pdf':
      return 'file-text';
    case 'document':
      return 'file';
    case 'manual':
      return 'book';
    default:
      return 'file';
  }
}
