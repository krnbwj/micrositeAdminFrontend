import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { PlusIcon, BookOpenIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import KnowledgeItem from "@/components/knowledge/KnowledgeItem";
import AddKnowledgeModal from "@/components/knowledge/AddKnowledgeModal";
import DeleteConfirmationDialog from "@/components/dialogs/DeleteConfirmationDialog";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { KnowledgeBase } from "@shared/schema";

export default function KnowledgeBasePage() {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<KnowledgeBase | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();

  // Fetch knowledge base data
  const { data: knowledgeItems = [], isLoading } = useQuery({
    queryKey: ["/api/knowledge"],
  });

  // Filter items based on search term
  const filteredItems = searchTerm
    ? knowledgeItems.filter(item => 
        item.content.toLowerCase().includes(searchTerm.toLowerCase()) || 
        item.source.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : knowledgeItems;

  const handleDeleteItem = async () => {
    if (!itemToDelete) return;
    
    try {
      await apiRequest("DELETE", `/api/knowledge/${itemToDelete.id}`);
      
      toast({
        title: "Item deleted",
        description: "Knowledge base item has been deleted successfully",
      });
      
      // Refresh knowledge base data
      queryClient.invalidateQueries({ queryKey: ["/api/knowledge"] });
      
      // Close dialog
      setItemToDelete(null);
    } catch (error) {
      console.error("Error deleting knowledge item:", error);
      toast({
        title: "Error",
        description: `Failed to delete item: ${error.message}`,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-semibold text-gray-900">Knowledge Base</h1>
          <Button 
            onClick={() => setIsAddModalOpen(true)}
            className="inline-flex items-center"
          >
            <PlusIcon className="mr-2 h-4 w-4" />
            Add Knowledge
          </Button>
        </div>
        
        <div className="mt-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Training Content</CardTitle>
              <CardDescription>
                Knowledge base content used to train the AI assistant
              </CardDescription>
              <div className="mt-4">
                <Input
                  placeholder="Search knowledge base..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="max-w-md"
                />
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex justify-center items-center py-20">
                  <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
                </div>
              ) : filteredItems.length > 0 ? (
                <div className="space-y-4">
                  {filteredItems.map((item) => (
                    <KnowledgeItem
                      key={item.id}
                      item={item}
                      onDelete={() => setItemToDelete(item)}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-10">
                  <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-gray-100">
                    <BookOpenIcon className="h-6 w-6 text-gray-400" />
                  </div>
                  <h3 className="mt-2 text-sm font-medium text-gray-900">
                    {searchTerm ? "No matching items found" : "Knowledge base is empty"}
                  </h3>
                  <p className="mt-1 text-sm text-gray-500">
                    {searchTerm 
                      ? "Try a different search term or clear the search" 
                      : "Get started by adding content to train your AI assistant"}
                  </p>
                  {!searchTerm && (
                    <div className="mt-6">
                      <Button onClick={() => setIsAddModalOpen(true)}>
                        <PlusIcon className="h-4 w-4 mr-2" />
                        Add Content
                      </Button>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Knowledge Base Tips</CardTitle>
              <CardDescription>Best practices for training your AI assistant</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-medium">Content Recommendations</h3>
                  <ul className="list-disc pl-5 mt-2 text-sm">
                    <li>Add your business description, services, and product information</li>
                    <li>Include pricing information and common FAQs</li>
                    <li>Add information about your business policies and procedures</li>
                    <li>Include industry-specific terminology and explanations</li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium">Best Practices</h3>
                  <ul className="list-disc pl-5 mt-2 text-sm">
                    <li>Keep content clear and concise</li>
                    <li>Break down complex information into smaller chunks</li>
                    <li>Include common customer questions and their answers</li>
                    <li>Regularly update information to ensure accuracy</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Add Knowledge Modal */}
      <AddKnowledgeModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
      />

      {/* Delete Confirmation Dialog */}
      <DeleteConfirmationDialog
        isOpen={!!itemToDelete}
        onClose={() => setItemToDelete(null)}
        onConfirm={handleDeleteItem}
        title="Delete Knowledge Item"
        description="Are you sure you want to delete this knowledge base item? This action cannot be undone."
        confirmLabel="Delete"
      />
    </div>
  );
}
