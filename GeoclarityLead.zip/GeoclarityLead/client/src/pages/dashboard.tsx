import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { LinkIcon, EyeIcon, MessageSquareIcon, BarChart3Icon, PlusIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import StatsCard from "@/components/dashboard/StatsCard";
import IntentDistributionChart from "@/components/dashboard/IntentDistributionChart";
import RecentLinksTable from "@/components/dashboard/RecentLinksTable";
import RecentConversations from "@/components/dashboard/RecentConversations";
import CreateLinkModal from "@/components/links/CreateLinkModal";
import { formatPercent } from "@/lib/utils";
import { Link } from "@shared/schema";

export default function Dashboard() {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [selectedLink, setSelectedLink] = useState<Link | null>(null);

  // Fetch dashboard stats
  const { data: stats, isLoading: isLoadingStats } = useQuery({
    queryKey: ["/api/stats"],
    refetchInterval: 60000, // Refetch every minute
  });

  // Fetch recent data
  const { data: dashboard, isLoading: isLoadingDashboard } = useQuery({
    queryKey: ["/api/dashboard"],
    refetchInterval: 60000, // Refetch every minute
  });

  const handleCreateLink = () => {
    setSelectedLink(null);
    setIsCreateModalOpen(true);
  };

  const handleEditLink = (link: Link) => {
    setSelectedLink(link);
    setIsCreateModalOpen(true);
  };

  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-semibold text-gray-900">Dashboard</h1>
          <div>
            <Button 
              onClick={handleCreateLink}
              className="inline-flex items-center"
            >
              <PlusIcon className="mr-2 h-4 w-4" />
              Create New Link
            </Button>
          </div>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mt-6">
          <StatsCard
            title="Total Links"
            value={isLoadingStats ? "-" : stats?.totalLinks || 0}
            icon={<LinkIcon className="h-6 w-6" />}
            iconBgColor="bg-primary-100"
            iconColor="text-primary-500"
          />
          
          <StatsCard
            title="Total Visits"
            value={isLoadingStats ? "-" : stats?.totalVisits || 0}
            icon={<EyeIcon className="h-6 w-6" />}
            iconBgColor="bg-warning-100"
            iconColor="text-warning-500"
          />
          
          <StatsCard
            title="Conversations"
            value={isLoadingStats ? "-" : stats?.totalConversations || 0}
            icon={<MessageSquareIcon className="h-6 w-6" />}
            iconBgColor="bg-success-100"
            iconColor="text-success-500"
          />
          
          <StatsCard
            title="Conversion Rate"
            value={isLoadingStats ? "-" : formatPercent(stats?.conversionRate || 0)}
            icon={<BarChart3Icon className="h-6 w-6" />}
            iconBgColor="bg-primary-100"
            iconColor="text-primary-500"
          />
        </div>
        
        {/* Intent Distribution Chart */}
        <IntentDistributionChart 
          data={isLoadingStats ? { NAVIGATIONAL: 0, TRANSACTIONAL: 0, INFORMATIONAL: 0 } : stats?.intentDistribution} 
          isLoading={isLoadingStats}
        />
        
        {/* Recent Links */}
        <RecentLinksTable 
          links={isLoadingDashboard ? [] : dashboard?.recentLinks || []}
          isLoading={isLoadingDashboard}
          onEditLink={handleEditLink}
        />
        
        {/* Recent Conversations */}
        <RecentConversations 
          conversations={isLoadingDashboard ? [] : dashboard?.recentConversations || []}
          isLoading={isLoadingDashboard}
        />
      </div>

      {/* Create/Edit Link Modal */}
      <CreateLinkModal 
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        linkToEdit={selectedLink || undefined}
      />
    </div>
  );
}
