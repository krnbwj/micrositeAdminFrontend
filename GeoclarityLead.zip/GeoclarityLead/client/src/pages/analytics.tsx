import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { BarChart3Icon, TrendingUpIcon, MessageSquareIcon, LinkIcon, EyeIcon } from "lucide-react";
import StatsCard from "@/components/dashboard/StatsCard";
import IntentDistributionChart from "@/components/dashboard/IntentDistributionChart";
import ConversionChart from "@/components/analytics/ConversionChart";
import VisitsChart from "@/components/analytics/VisitsChart";
import { formatPercent } from "@/lib/utils";

export default function Analytics() {
  // Fetch analytics data
  const { data: stats, isLoading: isLoadingStats } = useQuery({
    queryKey: ["/api/stats"],
    refetchInterval: 60000, // Refetch every minute
  });

  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-semibold text-gray-900">Analytics</h1>
        </div>
        
        <div className="mt-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
            <StatsCard
              title="Total Links"
              value={isLoadingStats ? "-" : stats?.totalLinks || 0}
              icon={<LinkIcon className="h-6 w-6" />}
              iconBgColor="bg-primary-100"
              iconColor="text-primary-500"
            />
            
            <StatsCard
              title="Total Visits"
              value={isLoadingStats ? "-" : stats?.totalVisits || 0}
              icon={<EyeIcon className="h-6 w-6" />}
              iconBgColor="bg-warning-100"
              iconColor="text-warning-500"
            />
            
            <StatsCard
              title="Conversations"
              value={isLoadingStats ? "-" : stats?.totalConversations || 0}
              icon={<MessageSquareIcon className="h-6 w-6" />}
              iconBgColor="bg-success-100"
              iconColor="text-success-500"
            />
            
            <StatsCard
              title="Conversion Rate"
              value={isLoadingStats ? "-" : formatPercent(stats?.conversionRate || 0)}
              icon={<TrendingUpIcon className="h-6 w-6" />}
              iconBgColor="bg-primary-100"
              iconColor="text-primary-500"
            />
          </div>
          
          {/* Charts */}
          <div className="mt-8">
            <Tabs defaultValue="intents">
              <TabsList className="grid w-full grid-cols-3 md:w-auto">
                <TabsTrigger value="intents">
                  <BarChart3Icon className="mr-2 h-4 w-4" />
                  Intent Distribution
                </TabsTrigger>
                <TabsTrigger value="conversion">
                  <TrendingUpIcon className="mr-2 h-4 w-4" />
                  Conversion Rate
                </TabsTrigger>
                <TabsTrigger value="visits">
                  <EyeIcon className="mr-2 h-4 w-4" />
                  Visit Trends
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="intents" className="mt-4">
                <IntentDistributionChart 
                  data={isLoadingStats ? { NAVIGATIONAL: 0, TRANSACTIONAL: 0, INFORMATIONAL: 0 } : stats?.intentDistribution} 
                  isLoading={isLoadingStats}
                />
              </TabsContent>
              
              <TabsContent value="conversion" className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Conversion Rate</CardTitle>
                    <CardDescription>Percentage of qualified leads over time</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[400px]">
                      <ConversionChart 
                        conversionRate={stats?.conversionRate || 0}
                        isLoading={isLoadingStats}
                      />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="visits" className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Visit Trends</CardTitle>
                    <CardDescription>Link visits over time</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[400px]">
                      <VisitsChart 
                        visits={stats?.totalVisits || 0}
                        isLoading={isLoadingStats}
                      />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
          
          {/* Information Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
            <Card>
              <CardHeader>
                <CardTitle>Lead Qualification Insights</CardTitle>
                <CardDescription>Understanding your lead quality</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h3 className="text-lg font-medium">Intent Distribution</h3>
                    <p className="text-sm text-gray-500">
                      Understanding visitor intents helps optimize your proxy links and content strategy:
                    </p>
                    <ul className="list-disc pl-5 mt-2 text-sm">
                      <li><span className="font-medium text-primary-500">Navigational</span>: Visitors looking to go to a specific page or section</li>
                      <li><span className="font-medium text-warning-500">Transactional</span>: Visitors ready to make a purchase or take action</li>
                      <li><span className="font-medium text-success-500">Informational</span>: Visitors seeking information about your products/services</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-medium">Qualified Leads</h3>
                    <p className="text-sm text-gray-500">
                      The AI determines lead qualification based on:
                    </p>
                    <ul className="list-disc pl-5 mt-2 text-sm">
                      <li>Specific inquiries about products/services</li>
                      <li>Expressions of purchase intent</li>
                      <li>Requests for quotes or pricing information</li>
                      <li>Contact information sharing intention</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Optimization Tips</CardTitle>
                <CardDescription>How to improve your lead generation</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h3 className="text-lg font-medium">Improve Conversations</h3>
                    <p className="text-sm text-gray-500">
                      Enhance your AI conversations with these tips:
                    </p>
                    <ul className="list-disc pl-5 mt-2 text-sm">
                      <li>Add more content to your knowledge base to improve AI responses</li>
                      <li>Review conversation transcripts to identify common questions</li>
                      <li>Create targeted proxy links for specific campaigns or channels</li>
                      <li>Test different UTM parameters to track marketing effectiveness</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-medium">Conversion Optimization</h3>
                    <p className="text-sm text-gray-500">
                      To increase your conversion rate:
                    </p>
                    <ul className="list-disc pl-5 mt-2 text-sm">
                      <li>Target high-intent keywords in your marketing campaigns</li>
                      <li>Ensure your destination pages match the conversation context</li>
                      <li>Follow up with qualified leads promptly</li>
                      <li>Optimize landing pages based on intent data</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
