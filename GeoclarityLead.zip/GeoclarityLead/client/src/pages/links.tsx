import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { PlusIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "@shared/schema";
import LinksList from "@/components/links/LinksList";
import CreateLinkModal from "@/components/links/CreateLinkModal";
import DeleteConfirmationDialog from "@/components/dialogs/DeleteConfirmationDialog";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Links() {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [selectedLink, setSelectedLink] = useState<Link | null>(null);
  const [linkToDelete, setLinkToDelete] = useState<Link | null>(null);
  const { toast } = useToast();

  // Fetch links data
  const { data: links, isLoading } = useQuery({
    queryKey: ["/api/links"],
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  const handleCreateLink = () => {
    setSelectedLink(null);
    setIsCreateModalOpen(true);
  };

  const handleEditLink = (link: Link) => {
    setSelectedLink(link);
    setIsCreateModalOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (!linkToDelete) return;
    
    try {
      await apiRequest("DELETE", `/api/links/${linkToDelete.id}`);
      
      toast({
        title: "Link deleted",
        description: "The proxy link has been deleted successfully",
      });
      
      // Refresh links data
      queryClient.invalidateQueries({ queryKey: ["/api/links"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      
      // Close dialog
      setLinkToDelete(null);
    } catch (error) {
      console.error("Error deleting link:", error);
      toast({
        title: "Error",
        description: `Failed to delete link: ${error.message}`,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-semibold text-gray-900">Proxy Links</h1>
          <Button 
            onClick={handleCreateLink}
            className="inline-flex items-center"
          >
            <PlusIcon className="mr-2 h-4 w-4" />
            Create New Link
          </Button>
        </div>
        
        <div className="mt-6">
          <LinksList 
            links={links || []}
            isLoading={isLoading}
            onCreateLink={handleCreateLink}
            onEditLink={handleEditLink}
            onDeleteLink={(link) => setLinkToDelete(link)}
          />
        </div>
      </div>

      {/* Create/Edit Link Modal */}
      <CreateLinkModal 
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        linkToEdit={selectedLink || undefined}
      />

      {/* Delete Confirmation Dialog */}
      <DeleteConfirmationDialog
        isOpen={!!linkToDelete}
        onClose={() => setLinkToDelete(null)}
        onConfirm={handleConfirmDelete}
        title="Delete Link"
        description={`Are you sure you want to delete the link "${linkToDelete?.name}"? This action cannot be undone.`}
        confirmLabel="Delete"
      />
    </div>
  );
}
