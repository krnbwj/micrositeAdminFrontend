import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import ConversationsList from "@/components/conversations/ConversationsList";
import ConversationDetails from "@/components/conversations/ConversationDetails";

interface Conversation {
  id: number;
  linkId: number;
  sessionId: string;
  startedAt: string;
  endedAt: string | null;
  intent: string | null;
  qualified: boolean | null;
  visitorIp: string | null;
}

export default function Conversations() {
  const [selectedConversationId, setSelectedConversationId] = useState<number | null>(null);

  // Fetch conversations data
  const { data: conversations, isLoading } = useQuery({
    queryKey: ["/api/conversations"],
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  // Find the selected conversation
  const selectedConversation = selectedConversationId 
    ? conversations?.find(c => c.id === selectedConversationId) 
    : null;

  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-semibold text-gray-900">Conversations</h1>
        </div>
        
        <div className="mt-6">
          {selectedConversation ? (
            <ConversationDetails 
              conversationId={selectedConversation.id}
              onBack={() => setSelectedConversationId(null)}
            />
          ) : (
            <ConversationsList 
              conversations={conversations || []}
              isLoading={isLoading}
              onViewDetails={(conversationId) => setSelectedConversationId(conversationId)}
            />
          )}
        </div>
      </div>
    </div>
  );
}
