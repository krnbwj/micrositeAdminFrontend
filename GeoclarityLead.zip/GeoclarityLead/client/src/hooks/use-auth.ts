import { useAuthContext } from "@/context/AuthContext";

// A simple hook to use the auth context
export function useAuth() {
  return useAuthContext();
}
