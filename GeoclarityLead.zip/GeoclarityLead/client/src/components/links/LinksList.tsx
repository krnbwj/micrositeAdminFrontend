import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "@shared/schema";
import { PlusIcon, LinkIcon, ClipboardIcon, EditIcon, TrashIcon } from "lucide-react";
import { useState } from "react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useToast } from "@/hooks/use-toast";
import { timeAgo } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

interface LinksListProps {
  links: Link[];
  isLoading?: boolean;
  onCreateLink?: () => void;
  onEditLink?: (link: Link) => void;
  onDeleteLink?: (link: Link) => void;
}

export default function LinksList({ 
  links, 
  isLoading = false,
  onCreateLink,
  onEditLink,
  onDeleteLink
}: LinksListProps) {
  const { toast } = useToast();
  const [copiedId, setCopiedId] = useState<number | null>(null);

  const copyToClipboard = (id: number, shortId: string) => {
    const fullUrl = `${window.location.origin}/r/${shortId}`;
    navigator.clipboard.writeText(fullUrl)
      .then(() => {
        setCopiedId(id);
        toast({
          title: "Copied to clipboard",
          description: "Link has been copied to clipboard",
        });
        setTimeout(() => setCopiedId(null), 2000);
      })
      .catch(err => {
        console.error('Could not copy text: ', err);
        toast({
          title: "Failed to copy",
          description: "Could not copy link to clipboard",
          variant: "destructive",
        });
      });
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div>
            <CardTitle>Proxy Links</CardTitle>
            <CardDescription>Manage your AI-powered proxy links</CardDescription>
          </div>
          {onCreateLink && (
            <Button onClick={onCreateLink}>
              <PlusIcon className="h-4 w-4 mr-2" /> Create Link
            </Button>
          )}
        </CardHeader>
        <CardContent className="py-2">
          <div className="flex justify-center items-center py-20">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (links.length === 0) {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div>
            <CardTitle>Proxy Links</CardTitle>
            <CardDescription>Manage your AI-powered proxy links</CardDescription>
          </div>
          {onCreateLink && (
            <Button onClick={onCreateLink}>
              <PlusIcon className="h-4 w-4 mr-2" /> Create Link
            </Button>
          )}
        </CardHeader>
        <CardContent className="py-10">
          <div className="text-center">
            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-gray-100">
              <LinkIcon className="h-6 w-6 text-gray-400" />
            </div>
            <h3 className="mt-2 text-sm font-medium text-gray-900">No links</h3>
            <p className="mt-1 text-sm text-gray-500">
              Get started by creating a new proxy link.
            </p>
            {onCreateLink && (
              <div className="mt-6">
                <Button onClick={onCreateLink}>
                  <PlusIcon className="h-4 w-4 mr-2" /> Create Link
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div>
          <CardTitle>Proxy Links</CardTitle>
          <CardDescription>Manage your AI-powered proxy links</CardDescription>
        </div>
        {onCreateLink && (
          <Button onClick={onCreateLink}>
            <PlusIcon className="h-4 w-4 mr-2" /> Create Link
          </Button>
        )}
      </CardHeader>
      <CardContent className="p-0">
        <div className="flex flex-col">
          <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
            <div className="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
              <div className="overflow-hidden">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Name
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Target URL
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Created
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Visits
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th scope="col" className="relative px-6 py-3">
                        <span className="sr-only">Actions</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {links.map((link) => (
                      <tr key={link.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10 flex items-center justify-center rounded-md bg-primary-100 text-primary-500">
                              <LinkIcon className="h-6 w-6" />
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">
                                {link.name}
                              </div>
                              <div className="flex items-center">
                                <span className="text-sm text-primary-500 mr-1">
                                  {window.location.origin}/r/{link.shortId}
                                </span>
                                <TooltipProvider>
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <Button 
                                        variant="ghost" 
                                        size="icon" 
                                        className="h-6 w-6" 
                                        onClick={() => copyToClipboard(link.id, link.shortId)}
                                      >
                                        {copiedId === link.id ? (
                                          <CheckIcon className="h-4 w-4 text-green-500" />
                                        ) : (
                                          <ClipboardIcon className="h-4 w-4 text-gray-400" />
                                        )}
                                      </Button>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      {copiedId === link.id ? "Copied!" : "Copy link"}
                                    </TooltipContent>
                                  </Tooltip>
                                </TooltipProvider>
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900 truncate max-w-xs">
                            {link.targetUrl}
                          </div>
                          {link.utmParams && (
                            <div className="text-xs text-gray-500 truncate max-w-xs">
                              UTM: {link.utmParams}
                            </div>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {timeAgo(new Date(link.createdAt))}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {link.visits}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <Badge variant={link.enableAi ? "success" : "secondary"}>
                            {link.enableAi ? "AI Enabled" : "Direct Redirect"}
                          </Badge>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium flex gap-2 justify-end">
                          {onEditLink && (
                            <Button 
                              variant="ghost" 
                              className="text-primary-500 hover:text-primary-700"
                              onClick={() => onEditLink(link)}
                            >
                              <EditIcon className="h-4 w-4 mr-1" /> Edit
                            </Button>
                          )}
                          {onDeleteLink && (
                            <Button 
                              variant="ghost" 
                              className="text-red-500 hover:text-red-700"
                              onClick={() => onDeleteLink(link)}
                            >
                              <TrashIcon className="h-4 w-4 mr-1" /> Delete
                            </Button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Check icon for copy confirmation
function CheckIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M20 6 9 17l-5-5" />
    </svg>
  );
}
