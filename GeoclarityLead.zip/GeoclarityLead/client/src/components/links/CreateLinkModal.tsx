import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useQuery } from "@tanstack/react-query";
import { KnowledgeBase } from "@shared/schema";

// Create form schema
const linkFormSchema = z.object({
  name: z.string().min(1, "Name is required"),
  targetUrl: z
    .string()
    .min(1, "Target URL is required")
    .url("Please enter a valid URL"),
  utmParams: z.string().optional(),
  enableAi: z.boolean().default(true),
  selectedKnowledgeIds: z.array(z.number()).optional(),
});

type LinkFormValues = z.infer<typeof linkFormSchema>;

interface CreateLinkModalProps {
  isOpen: boolean;
  onClose: () => void;
  linkToEdit?: {
    id: number;
    name: string;
    targetUrl: string;
    utmParams?: string;
    enableAi: boolean;
    selectedKnowledgeIds?: number[];
  };
}

export default function CreateLinkModal({ isOpen, onClose, linkToEdit }: CreateLinkModalProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedKnowledgeItems, setSelectedKnowledgeItems] = useState<number[]>(
    linkToEdit?.selectedKnowledgeIds ?? []
  );
  const { toast } = useToast();
  const isEditing = !!linkToEdit;

  // Fetch knowledge base items
  const { data: knowledgeItems = [] } = useQuery<KnowledgeBase[]>({
    queryKey: ["/api/knowledge"],
    enabled: isOpen, // Only fetch when modal is open
  });

  const form = useForm<LinkFormValues>({
    resolver: zodResolver(linkFormSchema),
    defaultValues: {
      name: linkToEdit?.name || "",
      targetUrl: linkToEdit?.targetUrl || "",
      utmParams: linkToEdit?.utmParams || "",
      enableAi: linkToEdit?.enableAi ?? true,
      selectedKnowledgeIds: linkToEdit?.selectedKnowledgeIds || [],
    },
  });
  
  // Update form value when selections change
  useEffect(() => {
    form.setValue('selectedKnowledgeIds', selectedKnowledgeItems);
  }, [selectedKnowledgeItems, form]);
  
  // Handle knowledge item selection
  const toggleKnowledgeItem = (id: number) => {
    setSelectedKnowledgeItems(prev => {
      if (prev.includes(id)) {
        return prev.filter(itemId => itemId !== id);
      } else {
        return [...prev, id];
      }
    });
  };

  async function onSubmit(data: LinkFormValues) {
    setIsSubmitting(true);
    try {
      if (isEditing && linkToEdit) {
        await apiRequest("PATCH", `/api/links/${linkToEdit.id}`, data);
        toast({
          title: "Link updated",
          description: "Your proxy link has been updated successfully",
        });
      } else {
        await apiRequest("POST", "/api/links", data);
        toast({
          title: "Link created",
          description: "Your new proxy link has been created successfully",
        });
      }
      
      // Invalidate queries to refetch links data
      queryClient.invalidateQueries({ queryKey: ["/api/links"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      
      // Close modal and reset form
      onClose();
      form.reset();
    } catch (error: any) {
      console.error("Error saving link:", error);
      toast({
        title: "Error",
        description: `Failed to ${isEditing ? 'update' : 'create'} link: ${error.message || "Unknown error"}`,
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>
            {isEditing ? "Edit Proxy Link" : "Create New Proxy Link"}
          </DialogTitle>
          <DialogDescription>
            {isEditing
              ? "Update your AI-powered proxy link to capture and qualify leads."
              : "Create a new AI-powered proxy link to capture and qualify leads before they reach your website."}
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="space-y-4">
            <div>
              <Label htmlFor="name">Link Name</Label>
              <Input
                id="name"
                placeholder="Google My Business Link"
                {...form.register("name")}
                className="mt-1"
              />
              {form.formState.errors.name && (
                <p className="text-sm text-red-500 mt-1">
                  {form.formState.errors.name.message}
                </p>
              )}
              <p className="mt-1 text-xs text-gray-500">
                This is for your reference only.
              </p>
            </div>
            
            <div>
              <Label htmlFor="targetUrl">Destination URL</Label>
              <Input
                id="targetUrl"
                placeholder="https://www.example.com/landing-page"
                {...form.register("targetUrl")}
                className="mt-1"
              />
              {form.formState.errors.targetUrl && (
                <p className="text-sm text-red-500 mt-1">
                  {form.formState.errors.targetUrl.message}
                </p>
              )}
              <p className="mt-1 text-xs text-gray-500">
                Where users will be directed after the AI conversation.
              </p>
            </div>
            
            <div>
              <div className="flex items-center justify-between">
                <Label htmlFor="utmParams">UTM Parameters</Label>
                <span className="text-xs text-gray-500">Optional</span>
              </div>
              <Input
                id="utmParams"
                placeholder="utm_source=gmb&utm_medium=proxy&utm_campaign=summer"
                {...form.register("utmParams")}
                className="mt-1"
              />
              {form.formState.errors.utmParams && (
                <p className="text-sm text-red-500 mt-1">
                  {form.formState.errors.utmParams.message}
                </p>
              )}
            </div>
            
            <div className="flex items-start">
              <div className="flex items-center h-5">
                <Checkbox
                  id="enableAi"
                  checked={form.watch("enableAi")}
                  onCheckedChange={(checked) => 
                    form.setValue("enableAi", checked as boolean)
                  }
                />
              </div>
              <div className="ml-3 text-sm">
                <Label htmlFor="enableAi" className="font-medium text-gray-700">
                  Enable AI Conversation
                </Label>
                <p className="text-gray-500">
                  Allow the AI to interact with visitors before redirecting them.
                </p>
              </div>
            </div>
            
            {form.watch("enableAi") && (
              <div>
                <Label className="text-base font-medium">Knowledge Base</Label>
                <p className="text-sm text-gray-500 mt-1 mb-2">
                  Select knowledge base items to use for this AI conversation
                </p>
                
                <div className="mt-2 space-y-2 max-h-60 overflow-y-auto border rounded-md p-2">
                  {knowledgeItems.length === 0 ? (
                    <div className="text-center py-4 text-gray-500">
                      <p>No knowledge base items available</p>
                      <p className="text-xs mt-1">Add content in the Knowledge Base section first</p>
                    </div>
                  ) : (
                    knowledgeItems.map((item: KnowledgeBase) => (
                      <div key={item.id} className="flex items-start py-2 border-b border-gray-100 last:border-0">
                        <Checkbox
                          id={`knowledge-${item.id}`}
                          checked={selectedKnowledgeItems.includes(item.id)}
                          onCheckedChange={() => toggleKnowledgeItem(item.id)}
                          className="mt-1"
                        />
                        <div className="ml-3">
                          <Label 
                            htmlFor={`knowledge-${item.id}`} 
                            className="font-medium cursor-pointer"
                          >
                            {item.source} 
                            <span className="ml-2 text-xs px-2 py-1 bg-gray-100 rounded-full">
                              ID: {item.id}
                            </span>
                          </Label>
                          <p className="text-sm text-gray-500 line-clamp-2 mt-1">
                            {item.content.substring(0, 100)}
                            {item.content.length > 100 ? "..." : ""}
                          </p>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button 
              type="button" 
              variant="outline" 
              onClick={onClose}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={isSubmitting}
            >
              {isSubmitting ? 
                <span className="flex items-center">
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  {isEditing ? "Updating..." : "Creating..."}
                </span> : 
                (isEditing ? "Update Link" : "Create Link")
              }
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}