import React from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useSidebarContext } from "@/context/SidebarContext";
import { 
  HomeIcon, 
  LinkIcon, 
  BarChart3Icon, 
  MessageSquareIcon, 
  BrainIcon, 
  SettingsIcon, 
  LogOutIcon,
  ShieldIcon
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function Sidebar() {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const { isSidebarOpen } = useSidebarContext();
  
  // Get the base path from the location
  const basePath = `/${location.split('/')[1]}`;

  const navItems = [
    { 
      name: "Dashboard", 
      path: "/", 
      icon: <HomeIcon className="mr-3 h-5 w-5" /> 
    },
    { 
      name: "Proxy Links", 
      path: "/links", 
      icon: <LinkIcon className="mr-3 h-5 w-5" /> 
    },
    { 
      name: "Conversations", 
      path: "/conversations", 
      icon: <MessageSquareIcon className="mr-3 h-5 w-5" /> 
    },
    { 
      name: "Analytics", 
      path: "/analytics", 
      icon: <BarChart3Icon className="mr-3 h-5 w-5" /> 
    },
    { 
      name: "Knowledge Base", 
      path: "/knowledge-base", 
      icon: <BrainIcon className="mr-3 h-5 w-5" /> 
    },
    { 
      name: "Settings", 
      path: "/settings", 
      icon: <SettingsIcon className="mr-3 h-5 w-5" /> 
    }
  ];

  // Determine CSS classes for visible/hidden sidebar
  const sidebarClasses = cn(
    "fixed md:relative inset-y-0 left-0 z-30 md:z-0 w-64 transition-transform duration-300 ease-in-out transform",
    isSidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
  );

  return (
    <div className={sidebarClasses}>
      <div className="flex flex-col h-full bg-gray-800 border-r border-gray-700">
        {/* Logo */}
        <div className="flex items-center justify-center h-16 px-4 bg-gray-900">
          <div className="flex items-center">
            <ShieldIcon className="h-8 w-8 text-primary" />
            <span className="ml-2 text-lg font-semibold text-white">LeadProxy AI</span>
          </div>
        </div>
        
        {/* Nav */}
        <div className="flex flex-col flex-grow px-4 py-4 overflow-y-auto">
          <div className="space-y-1">
            {navItems.map((item) => {
              const isActive = 
                (item.path === "/" && basePath === "/") || 
                (item.path !== "/" && basePath === item.path);
                
              return (
                <Link 
                  key={item.path} 
                  href={item.path}
                >
                  <a
                    className={cn(
                      "flex items-center px-2 py-2 text-sm font-medium rounded-md group",
                      isActive 
                        ? "text-white bg-gray-700" 
                        : "text-gray-300 hover:bg-gray-700 hover:text-white"
                    )}
                  >
                    {React.cloneElement(item.icon, { 
                      className: cn(
                        "mr-3 h-5 w-5",
                        isActive 
                          ? "text-white" 
                          : "text-gray-400 group-hover:text-white"
                      )
                    })}
                    {item.name}
                  </a>
                </Link>
              );
            })}
          </div>
          
          <div className="mt-auto">
            <div className="pt-4 border-t border-gray-700">
              {user && (
                <div className="flex items-center px-4 py-2">
                  <div className="flex-shrink-0">
                    <div className="h-8 w-8 rounded-full bg-gray-600 flex items-center justify-center text-white">
                      {user.username.charAt(0).toUpperCase()}
                    </div>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-white">{user.username}</p>
                    <p className="text-xs text-gray-400 truncate">{user.businessName || "Business Account"}</p>
                  </div>
                </div>
              )}
              <button
                onClick={() => logout()}
                className="w-full flex items-center px-2 py-2 text-sm font-medium text-gray-300 rounded-md hover:bg-gray-700 hover:text-white group"
              >
                <LogOutIcon className="mr-3 h-5 w-5 text-gray-400 group-hover:text-white" />
                Logout
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
