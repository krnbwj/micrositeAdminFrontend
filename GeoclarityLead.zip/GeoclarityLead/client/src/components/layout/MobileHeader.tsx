import { MenuIcon } from "lucide-react";
import { useSidebarContext } from "@/context/SidebarContext";
import { useAuth } from "@/hooks/use-auth";
import { ShieldIcon } from "lucide-react";

export default function MobileHeader() {
  const { toggleSidebar } = useSidebarContext();
  const { user } = useAuth();

  return (
    <div className="sticky top-0 z-10 md:hidden px-1 pt-1 sm:px-3 sm:pt-3 bg-gray-800 text-white shadow-md">
      <button 
        type="button" 
        className="inline-flex items-center justify-center p-2 rounded-md text-gray-300 hover:text-white hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white"
        onClick={toggleSidebar}
      >
        <MenuIcon className="h-6 w-6" />
        <div className="flex items-center ml-2">
          <ShieldIcon className="h-5 w-5 text-primary-500 mr-1" />
          <span className="text-lg font-semibold">LeadProxy AI</span>
          {user && <span className="ml-2 text-sm text-gray-400">({user.username})</span>}
        </div>
      </button>
    </div>
  );
}
