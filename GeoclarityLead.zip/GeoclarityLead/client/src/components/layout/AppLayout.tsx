import { ReactNode } from "react";
import Sidebar from "./Sidebar";
import MobileHeader from "./MobileHeader";
import { useSidebarContext } from "@/context/SidebarContext";

interface AppLayoutProps {
  children: ReactNode;
}

export default function AppLayout({ children }: AppLayoutProps) {
  const { isSidebarOpen, closeSidebar } = useSidebarContext();

  // Close the sidebar when clicking outside on mobile
  const handleMainClick = () => {
    if (isSidebarOpen) {
      closeSidebar();
    }
  };

  return (
    <div className="h-screen flex overflow-hidden bg-gray-50">
      {/* Sidebar */}
      <Sidebar />

      {/* Mobile overlay when sidebar is open */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 z-20 bg-gray-900/50 md:hidden"
          onClick={closeSidebar}
        />
      )}

      {/* Main Content */}
      <div className="flex flex-col w-0 flex-1 overflow-hidden" onClick={handleMainClick}>
        <MobileHeader />
        <main className="flex-1 relative z-0 overflow-y-auto focus:outline-none" tabIndex={0}>
          {children}
        </main>
      </div>
    </div>
  );
}
