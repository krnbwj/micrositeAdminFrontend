import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";
import { Card, CardContent } from "@/components/ui/card";

interface ConversionChartProps {
  conversionRate: number;
  isLoading?: boolean;
}

export default function ConversionChart({ conversionRate, isLoading = false }: ConversionChartProps) {
  // In a real implementation, this would use actual time-series data
  // For this MVP, we'll generate some fake data based on the current conversion rate
  const generateMockData = () => {
    const mockData = [];
    const today = new Date();
    
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(today.getDate() - i);
      
      // Vary the rate a bit around the actual conversion rate
      const variance = Math.random() * 10 - 5; // -5 to +5
      const rate = Math.max(0, Math.min(100, conversionRate + variance));
      
      mockData.push({
        date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        rate: parseFloat(rate.toFixed(1))
      });
    }
    
    return mockData;
  };
  
  const data = generateMockData();
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart
        data={data}
        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
      >
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
        <XAxis 
          dataKey="date" 
          stroke="#94a3b8"
          tick={{ fontSize: 12 }}
        />
        <YAxis 
          stroke="#94a3b8" 
          tick={{ fontSize: 12 }}
          domain={[0, 100]}
          tickFormatter={(value) => `${value}%`}
        />
        <Tooltip 
          formatter={(value) => [`${value}%`, "Conversion Rate"]}
          contentStyle={{ 
            backgroundColor: "white", 
            border: "1px solid #e2e8f0",
            borderRadius: "0.375rem",
            boxShadow: "0 1px 3px 0 rgba(0, 0, 0, 0.1)"
          }}
        />
        <Legend />
        <Line 
          type="monotone" 
          dataKey="rate" 
          stroke="#4F46E5" 
          strokeWidth={2}
          dot={{ r: 4, strokeWidth: 2 }}
          activeDot={{ r: 6 }}
          name="Conversion Rate"
        />
      </LineChart>
    </ResponsiveContainer>
  );
}
