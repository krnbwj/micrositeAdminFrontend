import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";

interface VisitsChartProps {
  visits: number;
  isLoading?: boolean;
}

export default function VisitsChart({ visits, isLoading = false }: VisitsChartProps) {
  // In a real implementation, this would use actual time-series data
  // For this MVP, we'll generate some mock data based on the total visits
  const generateMockData = () => {
    const mockData = [];
    const today = new Date();
    
    // Calculate daily average (roughly)
    const dailyAvg = Math.max(1, Math.floor(visits / 30));
    
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(today.getDate() - i);
      
      // Create some variance
      const dailyVisits = Math.max(0, dailyAvg + Math.floor(Math.random() * (dailyAvg / 2) - dailyAvg / 4));
      
      mockData.push({
        date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        visits: dailyVisits
      });
    }
    
    return mockData;
  };
  
  const data = generateMockData();
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart
        data={data}
        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
      >
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
        <XAxis 
          dataKey="date" 
          stroke="#94a3b8"
          tick={{ fontSize: 12 }}
        />
        <YAxis 
          stroke="#94a3b8" 
          tick={{ fontSize: 12 }}
        />
        <Tooltip 
          formatter={(value) => [value, "Visits"]}
          contentStyle={{ 
            backgroundColor: "white", 
            border: "1px solid #e2e8f0",
            borderRadius: "0.375rem",
            boxShadow: "0 1px 3px 0 rgba(0, 0, 0, 0.1)"
          }}
        />
        <Legend />
        <Bar 
          dataKey="visits" 
          fill="#F97316" 
          radius={[4, 4, 0, 0]}
          name="Daily Visits"
        />
      </BarChart>
    </ResponsiveContainer>
  );
}
