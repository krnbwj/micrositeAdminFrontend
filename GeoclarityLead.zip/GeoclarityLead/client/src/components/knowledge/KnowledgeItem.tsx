import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Badge } from "@/components/ui/badge";
import { TrashIcon, ChevronDownIcon, ChevronUpIcon, FileIcon, GlobeIcon, FileTextIcon, BookIcon } from "lucide-react";
import { KnowledgeBase } from "@shared/schema";

interface KnowledgeItemProps {
  item: KnowledgeBase;
  onDelete: () => void;
}

export default function KnowledgeItem({ item, onDelete }: KnowledgeItemProps) {
  const [isOpen, setIsOpen] = useState(false);
  
  // Get the right icon based on source
  const getSourceIcon = () => {
    switch (item.source.toLowerCase()) {
      case 'website':
        return <GlobeIcon className="h-4 w-4" />;
      case 'pdf':
        return <FileTextIcon className="h-4 w-4" />;
      case 'document':
        return <FileIcon className="h-4 w-4" />;
      case 'manual':
        return <BookIcon className="h-4 w-4" />;
      default:
        return <FileIcon className="h-4 w-4" />;
    }
  };
  
  // Get a preview of the content
  const contentPreview = item.content.length > 150 
    ? `${item.content.substring(0, 150)}...` 
    : item.content;
    
  // Get formatted metadata
  const getMetadata = () => {
    if (!item.metadata) return null;
    
    try {
      // Try to convert to string if it's an object
      const metadataStr = typeof item.metadata === 'object' 
        ? JSON.stringify(item.metadata, null, 2)
        : String(item.metadata);
        
      return metadataStr;
    } catch {
      return String(item.metadata);
    }
  };

  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow">
      <Collapsible
        open={isOpen}
        onOpenChange={setIsOpen}
        className="w-full"
      >
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {getSourceIcon()}
              <Badge variant="outline" className="capitalize">
                {item.source}
              </Badge>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={onDelete}
                className="text-red-500 hover:text-red-700 hover:bg-red-50"
              >
                <TrashIcon className="h-4 w-4" />
                <span className="sr-only">Delete</span>
              </Button>
              <CollapsibleTrigger asChild>
                <Button variant="ghost" size="sm">
                  {isOpen ? (
                    <ChevronUpIcon className="h-4 w-4" />
                  ) : (
                    <ChevronDownIcon className="h-4 w-4" />
                  )}
                  <span className="sr-only">Toggle</span>
                </Button>
              </CollapsibleTrigger>
            </div>
          </div>
          
          <div className="mt-2">
            <p className={isOpen ? "hidden" : "text-sm text-gray-700"}>
              {contentPreview}
            </p>
          </div>
          
          <CollapsibleContent>
            <div className="mt-2 bg-gray-50 p-3 rounded-md">
              <p className="text-sm text-gray-700 whitespace-pre-line">{item.content}</p>
              
              {getMetadata() && (
                <div className="mt-4 border-t border-gray-200 pt-3">
                  <p className="text-xs font-medium text-gray-500">Metadata:</p>
                  <pre className="text-xs text-gray-600 overflow-auto mt-1 bg-gray-100 p-2 rounded">
                    {getMetadata()}
                  </pre>
                </div>
              )}
            </div>
          </CollapsibleContent>
        </CardContent>
      </Collapsible>
    </Card>
  );
}
