import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";

interface AddKnowledgeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AddKnowledgeModal({ isOpen, onClose }: AddKnowledgeModalProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [content, setContent] = useState("");
  const [source, setSource] = useState("website");
  const [metadata, setMetadata] = useState("");
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!content.trim()) {
      toast({
        title: "Content required",
        description: "Please enter some content for the knowledge base",
        variant: "destructive",
      });
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Parse metadata if provided
      let parsedMetadata = undefined;
      if (metadata.trim()) {
        try {
          parsedMetadata = JSON.parse(metadata);
        } catch {
          toast({
            title: "Invalid metadata format",
            description: "Metadata must be valid JSON",
            variant: "destructive",
          });
          setIsSubmitting(false);
          return;
        }
      }
      
      await apiRequest("POST", "/api/knowledge", {
        content,
        source,
        metadata: parsedMetadata
      });
      
      toast({
        title: "Knowledge added",
        description: "Content has been added to your knowledge base",
      });
      
      // Refresh knowledge base data
      queryClient.invalidateQueries({ queryKey: ["/api/knowledge"] });
      
      // Reset form and close modal
      setContent("");
      setSource("website");
      setMetadata("");
      onClose();
    } catch (error) {
      console.error("Error adding knowledge:", error);
      toast({
        title: "Error",
        description: `Failed to add knowledge: ${error.message}`,
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>Add to Knowledge Base</DialogTitle>
            <DialogDescription>
              Add content to train your AI assistant. This content will be used to generate responses during conversations.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="content">Content *</Label>
              <Textarea
                id="content"
                placeholder="Enter knowledge content..."
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="h-40"
                required
              />
              <p className="text-xs text-gray-500">
                Enter information about your business, products, services, FAQs, etc.
              </p>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="source">Source *</Label>
              <Select
                value={source}
                onValueChange={setSource}
              >
                <SelectTrigger id="source">
                  <SelectValue placeholder="Select source" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="website">Website</SelectItem>
                  <SelectItem value="pdf">PDF Document</SelectItem>
                  <SelectItem value="document">Text Document</SelectItem>
                  <SelectItem value="manual">Manual Entry</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="metadata">
                Metadata <span className="text-xs text-gray-500">(Optional JSON)</span>
              </Label>
              <Textarea
                id="metadata"
                placeholder='{"key": "value"}'
                value={metadata}
                onChange={(e) => setMetadata(e.target.value)}
                className="h-20"
              />
              <p className="text-xs text-gray-500">
                Optional JSON metadata to provide context for this content.
              </p>
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              type="button" 
              variant="outline" 
              onClick={onClose}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={isSubmitting || !content.trim()}
            >
              {isSubmitting ? (
                <span className="flex items-center">
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Adding...
                </span>
              ) : "Add to Knowledge Base"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
