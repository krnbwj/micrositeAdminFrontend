import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ShieldIcon, SendIcon, X as CloseIcon } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import ChatMessage from './ChatMessage';

interface ConversationInterfaceProps {
  isOpen: boolean;
  onClose: () => void;
  linkId: number;
  businessName?: string;
  onConversationComplete?: (intent: string, qualified: boolean) => void;
}

interface Message {
  id?: number;
  role: 'user' | 'assistant';
  content: string;
  timestamp?: string;
}

export default function ConversationInterface({ 
  isOpen, 
  onClose, 
  linkId,
  businessName = "Virtual Assistant",
  onConversationComplete
}: ConversationInterfaceProps) {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [sessionId, setSessionId] = useState('');
  const [conversationId, setConversationId] = useState<number | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    // Generate random session ID when component mounts
    setSessionId(Math.random().toString(36).substring(2, 15));
    
    // Add initial greeting message
    const initialMessage: Message = {
      role: 'assistant',
      content: `Hi there! 👋 I'm the virtual assistant for ${businessName}. How can I help you today?`
    };
    setMessages([initialMessage]);
    
    // Create a new conversation
    const createConversation = async () => {
      try {
        const res = await apiRequest('POST', '/api/conversations', {
          linkId,
          sessionId: Math.random().toString(36).substring(2, 15),
          visitorIp: 'unknown' // In a real app, this would be handled by the server
        });
        const data = await res.json();
        setConversationId(data.id);
      } catch (error) {
        console.error('Error creating conversation:', error);
      }
    };
    
    createConversation();
  }, [linkId, businessName]);
  
  useEffect(() => {
    // Scroll to bottom whenever messages change
    scrollToBottom();
  }, [messages]);
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  const handleSend = async () => {
    if (!input.trim() || !conversationId) return;
    
    const userMessage = input;
    setInput('');
    setIsTyping(true);
    
    // Add user message to conversation
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    
    try {
      const response = await apiRequest('POST', '/api/messages', {
        conversationId,
        content: userMessage,
        role: 'user'
      });
      
      const data = await response.json();
      
      // Add assistant response to conversation
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: data.aiMessage.content 
      }]);
      
      // If conversation is completed based on intent, notify parent
      if (onConversationComplete && (data.intent === 'NAVIGATIONAL' || data.intent === 'TRANSACTIONAL')) {
        setTimeout(() => {
          onConversationComplete(data.intent, data.qualified);
        }, 3000);
      }
    } catch (error) {
      console.error('Error sending message:', error);
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: 'Sorry, I encountered an error. Please try again.' 
      }]);
    } finally {
      setIsTyping(false);
    }
  };
  
  // Handle Enter key to send message
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };
  
  if (!isOpen) return null;
  
  return (
    <div className="fixed z-10 inset-0 overflow-hidden">
      <div className="absolute inset-0 overflow-hidden">
        <div className="pointer-events-none fixed inset-y-0 right-0 flex max-w-full">
          <div className="pointer-events-auto w-screen max-w-md">
            <div className="flex h-full flex-col overflow-hidden bg-white shadow-xl">
              <div className="bg-primary px-4 py-6 sm:px-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-medium text-white" id="slide-over-title">
                    <div className="flex items-center">
                      <ShieldIcon className="h-6 w-6 mr-2" />
                      {businessName}
                    </div>
                  </h2>
                  <button 
                    type="button" 
                    className="rounded-md text-white hover:text-gray-200 focus:outline-none"
                    onClick={onClose}
                  >
                    <span className="sr-only">Close panel</span>
                    <CloseIcon className="h-6 w-6" />
                  </button>
                </div>
                <div className="mt-1">
                  <p className="text-sm text-white opacity-80">
                    AI-powered assistant
                  </p>
                </div>
              </div>
              
              <div className="relative flex-1 overflow-y-auto px-4 py-6 sm:px-6">
                {/* Chat messages */}
                <div className="space-y-4">
                  {messages.map((msg, index) => (
                    <ChatMessage 
                      key={index} 
                      message={msg} 
                    />
                  ))}
                  
                  {isTyping && (
                    <ChatMessage 
                      message={{ role: 'assistant', content: '' }}
                      isTyping={true}
                    />
                  )}
                  <div ref={messagesEndRef} />
                </div>
              </div>
              
              <div className="border-t border-gray-200 p-4 sm:p-6">
                <div className="flex items-center">
                  <div className="flex-grow">
                    <Textarea
                      rows={1}
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      onKeyPress={handleKeyPress}
                      className="block w-full resize-none rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm"
                      placeholder="Type your message..."
                      disabled={isTyping}
                    />
                  </div>
                  <div className="ml-4 flex-shrink-0">
                    <Button 
                      onClick={handleSend}
                      disabled={isTyping || !input.trim()}
                      className="inline-flex items-center"
                    >
                      <SendIcon className="-ml-1 mr-2 h-5 w-5" />
                      Send
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
