import { Avatar, AvatarFallback } from '@/components/ui/avatar';

interface ChatMessageProps {
  message: {
    role: 'user' | 'assistant';
    content: string;
  };
  isTyping?: boolean;
}

export default function ChatMessage({ message, isTyping = false }: ChatMessageProps) {
  const { role, content } = message;
  
  if (role === 'assistant') {
    return (
      <div className="flex items-start">
        <div className="flex-shrink-0">
          <Avatar className="h-8 w-8">
            <AvatarFallback className="bg-primary-100">
              <span className="text-sm font-medium text-primary-800">AI</span>
            </AvatarFallback>
          </Avatar>
        </div>
        <div className="ml-3">
          <div className="rounded-lg bg-primary-50 px-4 py-2 text-sm">
            {isTyping ? (
              <div className="typing-indicator">
                <span></span>
                <span></span>
                <span></span>
              </div>
            ) : (
              <p className="whitespace-pre-line">{content}</p>
            )}
          </div>
        </div>
      </div>
    );
  }
  
  // User message
  return (
    <div className="flex items-start justify-end">
      <div className="mr-3">
        <div className="rounded-lg bg-gray-100 px-4 py-2 text-sm">
          <p className="whitespace-pre-line">{content}</p>
        </div>
      </div>
      <div className="flex-shrink-0">
        <Avatar className="h-8 w-8">
          <AvatarFallback className="bg-gray-200">
            <span className="text-sm font-medium text-gray-600">You</span>
          </AvatarFallback>
        </Avatar>
      </div>
    </div>
  );
}
