import { Link as WouterLink } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LinkIcon, EditIcon, TrashIcon } from "lucide-react";
import { timeAgo } from "@/lib/utils";
import { Link } from "@shared/schema";

interface RecentLinksTableProps {
  links: Link[];
  isLoading?: boolean;
  onEditLink?: (link: Link) => void;
  onDeleteLink?: (link: Link) => void;
}

export default function RecentLinksTable({ 
  links, 
  isLoading = false,
  onEditLink,
  onDeleteLink
}: RecentLinksTableProps) {
  if (isLoading) {
    return (
      <Card className="mt-8">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div>
            <CardTitle>Recent Links</CardTitle>
            <CardDescription>Your most recently created proxy links</CardDescription>
          </div>
          <WouterLink href="/links">
            <Button variant="link" className="text-sm font-medium text-primary-500 hover:text-primary-600">View all</Button>
          </WouterLink>
        </CardHeader>
        <CardContent className="py-2">
          <div className="flex justify-center items-center py-20">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (links.length === 0) {
    return (
      <Card className="mt-8">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div>
            <CardTitle>Recent Links</CardTitle>
            <CardDescription>Your most recently created proxy links</CardDescription>
          </div>
          <WouterLink href="/links">
            <Button variant="link" className="text-sm font-medium text-primary-500 hover:text-primary-600">View all</Button>
          </WouterLink>
        </CardHeader>
        <CardContent className="py-10">
          <div className="text-center">
            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-gray-100">
              <LinkIcon className="h-6 w-6 text-gray-400" />
            </div>
            <h3 className="mt-2 text-sm font-medium text-gray-900">No links</h3>
            <p className="mt-1 text-sm text-gray-500">
              You haven't created any proxy links yet.
            </p>
            <div className="mt-6">
              <WouterLink href="/links">
                <Button variant="default" size="sm">
                  Create new link
                </Button>
              </WouterLink>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="mt-8">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div>
          <CardTitle>Recent Links</CardTitle>
          <CardDescription>Your most recently created proxy links</CardDescription>
        </div>
        <WouterLink href="/links">
          <Button variant="link" className="text-sm font-medium text-primary-500 hover:text-primary-600">View all</Button>
        </WouterLink>
      </CardHeader>
      <CardContent className="p-0">
        <div className="flex flex-col">
          <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
            <div className="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
              <div className="overflow-hidden">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Name
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Target URL
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Created
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Visits
                      </th>
                      <th scope="col" className="relative px-6 py-3">
                        <span className="sr-only">Actions</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {links.map((link) => (
                      <tr key={link.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10 flex items-center justify-center rounded-md bg-primary-100 text-primary-500">
                              <LinkIcon className="h-6 w-6" />
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">
                                {link.name}
                              </div>
                              <div className="text-sm text-primary-500">
                                {window.location.origin}/r/{link.shortId}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900 truncate max-w-xs">
                            {link.targetUrl}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {timeAgo(new Date(link.createdAt))}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {link.visits}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          {onEditLink && (
                            <Button 
                              variant="ghost" 
                              className="text-primary-500 hover:text-primary-700 mr-3"
                              onClick={() => onEditLink(link)}
                            >
                              <EditIcon className="h-4 w-4 mr-1" /> Edit
                            </Button>
                          )}
                          {onDeleteLink && (
                            <Button 
                              variant="ghost" 
                              className="text-red-500 hover:text-red-700"
                              onClick={() => onDeleteLink(link)}
                            >
                              <TrashIcon className="h-4 w-4 mr-1" /> Delete
                            </Button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
