import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { MessageSquareIcon } from "lucide-react";
import { timeAgo } from "@/lib/utils";

interface Conversation {
  id: number;
  startedAt: string;
  intent: string | null;
  qualified: boolean | null;
  link: {
    id: number;
    name: string;
  };
  messages: {
    id: number;
    role: string;
    content: string;
  }[];
}

interface RecentConversationsProps {
  conversations: Conversation[];
  isLoading?: boolean;
  onViewDetails?: (conversation: Conversation) => void;
}

export default function RecentConversations({ 
  conversations, 
  isLoading = false,
  onViewDetails
}: RecentConversationsProps) {
  if (isLoading) {
    return (
      <Card className="mt-8">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div>
            <CardTitle>Recent Conversations</CardTitle>
            <CardDescription>Your most recent AI-lead interactions</CardDescription>
          </div>
          <Link href="/conversations">
            <Button variant="link" className="text-sm font-medium text-primary-500 hover:text-primary-600">View all</Button>
          </Link>
        </CardHeader>
        <CardContent className="py-2">
          <div className="flex justify-center items-center py-20">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (conversations.length === 0) {
    return (
      <Card className="mt-8">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div>
            <CardTitle>Recent Conversations</CardTitle>
            <CardDescription>Your most recent AI-lead interactions</CardDescription>
          </div>
          <Link href="/conversations">
            <Button variant="link" className="text-sm font-medium text-primary-500 hover:text-primary-600">View all</Button>
          </Link>
        </CardHeader>
        <CardContent className="py-10">
          <div className="text-center">
            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-gray-100">
              <MessageSquareIcon className="h-6 w-6 text-gray-400" />
            </div>
            <h3 className="mt-2 text-sm font-medium text-gray-900">No conversations</h3>
            <p className="mt-1 text-sm text-gray-500">
              No conversations have happened yet.
            </p>
            <div className="mt-6">
              <Link href="/links">
                <Button variant="default" size="sm">
                  Create proxy links
                </Button>
              </Link>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Get the intent badge color
  const getIntentBadgeVariant = (intent: string | null) => {
    switch (intent) {
      case 'NAVIGATIONAL':
        return 'outline';
      case 'TRANSACTIONAL':
        return 'warning';
      case 'INFORMATIONAL':
        return 'success';
      default:
        return 'secondary';
    }
  };

  // Format intent for display
  const formatIntent = (intent: string | null) => {
    if (!intent) return 'Unknown Intent';
    
    return intent.charAt(0) + intent.slice(1).toLowerCase() + ' Intent';
  };

  return (
    <Card className="mt-8 mb-8">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div>
          <CardTitle>Recent Conversations</CardTitle>
          <CardDescription>Your most recent AI-lead interactions</CardDescription>
        </div>
        <Link href="/conversations">
          <Button variant="link" className="text-sm font-medium text-primary-500 hover:text-primary-600">View all</Button>
        </Link>
      </CardHeader>
      <CardContent className="p-0">
        <div className="divide-y divide-gray-200">
          {conversations.map((conversation) => {
            // Get first few messages for preview
            const messages = conversation.messages || [];
            
            // Generate visitor identifier
            const visitorId = `Visitor #${conversation.id}`;

            return (
              <div key={conversation.id} className="p-6">
                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    <Avatar>
                      <AvatarFallback className="bg-primary-100 text-primary-700">
                        {visitorId.charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                  </div>
                  <div className="ml-4 flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="text-sm font-medium text-gray-900">{visitorId}</h4>
                      <span className="text-xs text-gray-500">{timeAgo(new Date(conversation.startedAt))}</span>
                    </div>
                    <div className="mt-1">
                      <div className="text-sm text-gray-500 bg-gray-50 p-3 rounded-lg">
                        {messages.length > 0 ? (
                          <>
                            {messages.map((msg, idx) => (
                              <p key={msg.id} className={`${idx > 0 ? 'mt-1' : ''} ${msg.role === 'assistant' ? 'font-medium text-gray-900' : ''}`}>
                                {msg.role === 'assistant' ? 'AI: ' : 'Customer: '}{msg.content}
                              </p>
                            ))}
                            {messages.length < conversation.messages.length && (
                              <p className="text-xs text-gray-400 mt-1">
                                {conversation.messages.length - messages.length} more message(s)...
                              </p>
                            )}
                          </>
                        ) : (
                          <p className="italic text-gray-400">No messages in this conversation</p>
                        )}
                      </div>
                    </div>
                    <div className="mt-2 flex justify-between">
                      <div>
                        <Badge variant={getIntentBadgeVariant(conversation.intent)} className="mr-2">
                          {formatIntent(conversation.intent)}
                        </Badge>
                        {conversation.qualified !== null && (
                          <Badge variant={conversation.qualified ? 'success' : 'secondary'}>
                            {conversation.qualified ? 'Qualified Lead' : 'Not Qualified'}
                          </Badge>
                        )}
                      </div>
                      {onViewDetails && (
                        <Button 
                          variant="link" 
                          className="text-sm text-primary-500 hover:text-primary-700"
                          onClick={() => onViewDetails(conversation)}
                        >
                          View Details
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
