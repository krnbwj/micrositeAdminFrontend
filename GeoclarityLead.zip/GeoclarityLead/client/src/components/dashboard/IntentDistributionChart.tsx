import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell
} from "recharts";

interface IntentDistributionProps {
  data: {
    NAVIGATIONAL: number;
    TRANSACTIONAL: number;
    INFORMATIONAL: number;
  };
  isLoading?: boolean;
}

export default function IntentDistributionChart({ data, isLoading = false }: IntentDistributionProps) {
  // Format data for the chart
  const chartData = [
    { name: "Navigational", value: data.NAVIGATIONAL, color: "#4F46E5" },
    { name: "Transactional", value: data.TRANSACTIONAL, color: "#F97316" },
    { name: "Informational", value: data.INFORMATIONAL, color: "#10B981" },
  ];

  // Calculate total for percentages
  const total = Object.values(data).reduce((sum, val) => sum + val, 0);

  // Calculate percentages
  const withPercentages = chartData.map(item => ({
    ...item,
    percentage: total > 0 ? Math.round((item.value / total) * 100) : 0
  }));

  if (isLoading) {
    return (
      <Card className="mt-8">
        <CardHeader>
          <CardTitle>Intent Distribution</CardTitle>
          <CardDescription>Distribution of user intents from conversations</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-64 flex items-center justify-center">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (total === 0) {
    return (
      <Card className="mt-8">
        <CardHeader>
          <CardTitle>Intent Distribution</CardTitle>
          <CardDescription>Distribution of user intents from conversations</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-64 flex items-center justify-center text-gray-500">
            No conversation data available yet
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="mt-8">
      <CardHeader>
        <CardTitle>Intent Distribution</CardTitle>
        <CardDescription>Distribution of user intents from conversations</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={withPercentages}
              margin={{ top: 20, right: 30, left: 20, bottom: 40 }}
            >
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip
                formatter={(value, name, props) => [`${value} conversations (${props.payload.percentage}%)`, "Count"]}
              />
              <Bar dataKey="value" barSize={60}>
                {withPercentages.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}
