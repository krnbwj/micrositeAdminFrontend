import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ArrowLeftIcon, ClockIcon, TagIcon, InfoIcon, LinkIcon, UserIcon } from "lucide-react";
import { timeAgo } from "@/lib/utils";
import { formatIntent, getIntentColor } from "@/lib/conversations";

interface ConversationDetailsProps {
  conversationId: number;
  onBack: () => void;
}

export default function ConversationDetails({ conversationId, onBack }: ConversationDetailsProps) {
  // Fetch conversation details including messages
  const { data, isLoading, error } = useQuery({
    queryKey: [`/api/conversations/${conversationId}`],
  });
  
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Button variant="ghost" size="sm" onClick={onBack} className="mb-2 w-fit">
            <ArrowLeftIcon className="h-4 w-4 mr-2" />
            Back to conversations
          </Button>
          <CardTitle>Loading Conversation...</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-center items-center py-20">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  if (error || !data) {
    return (
      <Card>
        <CardHeader>
          <Button variant="ghost" size="sm" onClick={onBack} className="mb-2 w-fit">
            <ArrowLeftIcon className="h-4 w-4 mr-2" />
            Back to conversations
          </Button>
          <CardTitle>Error Loading Conversation</CardTitle>
          <CardDescription>
            There was an error loading this conversation. Please try again.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="py-10 text-center text-red-500">
            {error instanceof Error ? error.message : "Unknown error occurred"}
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={onBack}>Return to Conversations</Button>
        </CardFooter>
      </Card>
    );
  }
  
  const { conversation, messages } = data;
  const link = conversation.link;
  
  return (
    <Card>
      <CardHeader>
        <Button variant="ghost" size="sm" onClick={onBack} className="mb-2 w-fit">
          <ArrowLeftIcon className="h-4 w-4 mr-2" />
          Back to conversations
        </Button>
        <CardTitle className="flex items-center">
          Conversation Details
          <Badge variant="outline" className="ml-2">
            ID: {conversation.id}
          </Badge>
        </CardTitle>
        <CardDescription>
          Conversation started {timeAgo(new Date(conversation.startedAt))}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Information Panel */}
          <div className="md:col-span-1 space-y-6">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="text-sm font-medium flex items-center mb-3">
                <InfoIcon className="h-4 w-4 mr-2 text-gray-500" />
                Conversation Info
              </h3>
              
              <div className="space-y-3">
                <div>
                  <p className="text-xs text-gray-500">Session ID</p>
                  <p className="text-sm font-mono break-all">{conversation.sessionId}</p>
                </div>
                
                <div>
                  <p className="text-xs text-gray-500">Started At</p>
                  <p className="text-sm flex items-center">
                    <ClockIcon className="h-3 w-3 mr-1 text-gray-400" />
                    {new Date(conversation.startedAt).toLocaleString()}
                  </p>
                </div>
                
                {conversation.endedAt && (
                  <div>
                    <p className="text-xs text-gray-500">Ended At</p>
                    <p className="text-sm flex items-center">
                      <ClockIcon className="h-3 w-3 mr-1 text-gray-400" />
                      {new Date(conversation.endedAt).toLocaleString()}
                    </p>
                  </div>
                )}
                
                {conversation.visitorIp && (
                  <div>
                    <p className="text-xs text-gray-500">Visitor IP</p>
                    <p className="text-sm flex items-center">
                      <UserIcon className="h-3 w-3 mr-1 text-gray-400" />
                      {conversation.visitorIp}
                    </p>
                  </div>
                )}
              </div>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="text-sm font-medium flex items-center mb-3">
                <LinkIcon className="h-4 w-4 mr-2 text-gray-500" />
                Link Details
              </h3>
              
              {link ? (
                <div className="space-y-3">
                  <div>
                    <p className="text-xs text-gray-500">Link Name</p>
                    <p className="text-sm font-medium">{link.name}</p>
                  </div>
                  
                  <div>
                    <p className="text-xs text-gray-500">Proxy URL</p>
                    <p className="text-sm text-primary-500 break-all">
                      {window.location.origin}/r/{link.shortId}
                    </p>
                  </div>
                  
                  <div>
                    <p className="text-xs text-gray-500">Target URL</p>
                    <p className="text-sm break-all">{link.targetUrl}</p>
                  </div>
                  
                  {link.utmParams && (
                    <div>
                      <p className="text-xs text-gray-500">UTM Parameters</p>
                      <p className="text-sm font-mono text-xs">{link.utmParams}</p>
                    </div>
                  )}
                </div>
              ) : (
                <p className="text-sm text-gray-500">Link information not available</p>
              )}
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="text-sm font-medium flex items-center mb-3">
                <TagIcon className="h-4 w-4 mr-2 text-gray-500" />
                Classification
              </h3>
              
              <div className="space-y-3">
                <div>
                  <p className="text-xs text-gray-500">Intent</p>
                  {conversation.intent ? (
                    <Badge variant={getIntentColor(conversation.intent) as any}>
                      {formatIntent(conversation.intent)}
                    </Badge>
                  ) : (
                    <p className="text-sm text-gray-500">Not classified</p>
                  )}
                </div>
                
                <div>
                  <p className="text-xs text-gray-500">Lead Status</p>
                  {conversation.qualified !== null ? (
                    <Badge variant={conversation.qualified ? "success" : "secondary"}>
                      {conversation.qualified ? "Qualified Lead" : "Not Qualified"}
                    </Badge>
                  ) : (
                    <p className="text-sm text-gray-500">Not determined</p>
                  )}
                </div>
              </div>
            </div>
          </div>
          
          {/* Conversation Transcript */}
          <div className="md:col-span-2 bg-white border rounded-lg p-4">
            <h3 className="text-sm font-medium mb-4">Conversation Transcript</h3>
            
            {messages && messages.length > 0 ? (
              <div className="space-y-4">
                {messages.map((message) => (
                  <div key={message.id} className="flex items-start gap-3">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className={message.role === 'assistant' ? 'bg-primary-100 text-primary-800' : 'bg-gray-200 text-gray-800'}>
                        {message.role === 'assistant' ? 'AI' : 'U'}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-medium">
                          {message.role === 'assistant' ? 'AI Assistant' : 'User'}
                        </p>
                        <span className="text-xs text-gray-500">
                          {new Date(message.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                      <div className={`mt-1 p-3 text-sm rounded-lg ${
                        message.role === 'assistant' 
                          ? 'bg-primary-50'
                          : 'bg-gray-100'
                      }`}>
                        <p className="whitespace-pre-line">{message.content}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-10 text-gray-500">
                No messages in this conversation
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
