import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { MessageSquareIcon, SearchIcon, FilterIcon, ChevronRightIcon } from "lucide-react";
import { timeAgo } from "@/lib/utils";
import { formatIntent, getIntentColor } from "@/lib/conversations";

interface Conversation {
  id: number;
  linkId: number;
  sessionId: string;
  startedAt: string;
  endedAt: string | null;
  intent: string | null;
  qualified: boolean | null;
  visitorIp: string | null;
}

interface ConversationsListProps {
  conversations: Conversation[];
  isLoading?: boolean;
  onViewDetails: (conversationId: number) => void;
}

export default function ConversationsList({ 
  conversations, 
  isLoading = false, 
  onViewDetails
}: ConversationsListProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [intentFilter, setIntentFilter] = useState("all");
  const [qualifiedFilter, setQualifiedFilter] = useState("all");

  // Filter conversations based on search and filters
  const filteredConversations = conversations.filter(conversation => {
    // Search filter
    const matchesSearch = searchTerm === "" || 
      conversation.sessionId.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Intent filter
    const matchesIntent = intentFilter === "all" || 
      (conversation.intent === intentFilter);
    
    // Qualified filter
    const matchesQualified = qualifiedFilter === "all" || 
      (qualifiedFilter === "qualified" && conversation.qualified === true) ||
      (qualifiedFilter === "notqualified" && conversation.qualified === false);
    
    return matchesSearch && matchesIntent && matchesQualified;
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Conversations</CardTitle>
          <CardDescription>View and analyze customer interactions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex justify-center items-center py-20">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (conversations.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Conversations</CardTitle>
          <CardDescription>View and analyze customer interactions</CardDescription>
        </CardHeader>
        <CardContent className="py-10">
          <div className="text-center">
            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-gray-100">
              <MessageSquareIcon className="h-6 w-6 text-gray-400" />
            </div>
            <h3 className="mt-2 text-sm font-medium text-gray-900">No conversations</h3>
            <p className="mt-1 text-sm text-gray-500">
              No customers have interacted with your proxy links yet.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Conversations</CardTitle>
        <CardDescription>View and analyze customer interactions</CardDescription>
        
        {/* Filter and Search */}
        <div className="mt-4 flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
            <Input
              placeholder="Search by session ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
          
          <div className="flex flex-wrap gap-2">
            <div className="flex items-center space-x-2">
              <FilterIcon className="h-4 w-4 text-gray-500" />
              <Select
                value={intentFilter}
                onValueChange={setIntentFilter}
              >
                <SelectTrigger className="w-[160px]">
                  <SelectValue placeholder="Filter by intent" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Intents</SelectItem>
                  <SelectItem value="NAVIGATIONAL">Navigational</SelectItem>
                  <SelectItem value="TRANSACTIONAL">Transactional</SelectItem>
                  <SelectItem value="INFORMATIONAL">Informational</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center">
              <Select
                value={qualifiedFilter}
                onValueChange={setQualifiedFilter}
              >
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Filter by qualification" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Leads</SelectItem>
                  <SelectItem value="qualified">Qualified Leads</SelectItem>
                  <SelectItem value="notqualified">Not Qualified</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {filteredConversations.length === 0 ? (
          <div className="text-center py-10 text-gray-500">
            No conversations match your search and filters
          </div>
        ) : (
          <div className="space-y-4">
            {filteredConversations.map((conversation) => (
              <div 
                key={conversation.id} 
                className="border rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => onViewDetails(conversation.id)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback className="bg-primary-100 text-primary-800">
                        {conversation.id % 10}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div className="ml-3">
                      <div className="flex items-center">
                        <h4 className="text-sm font-medium text-gray-900">
                          Visitor #{conversation.id}
                        </h4>
                        <span className="ml-2 text-xs text-gray-500">
                          {timeAgo(new Date(conversation.startedAt))}
                        </span>
                      </div>
                      
                      <p className="mt-1 text-xs text-gray-500">
                        Session: <span className="font-mono">{conversation.sessionId.substring(0, 12)}...</span>
                      </p>
                      
                      <div className="mt-2 flex flex-wrap gap-2">
                        {conversation.intent && (
                          <Badge variant={getIntentColor(conversation.intent) as any}>
                            {formatIntent(conversation.intent)}
                          </Badge>
                        )}
                        
                        {conversation.qualified !== null && (
                          <Badge variant={conversation.qualified ? "success" : "secondary"}>
                            {conversation.qualified ? "Qualified Lead" : "Not Qualified"}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <Button variant="ghost" size="icon">
                    <ChevronRightIcon className="h-5 w-5" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
