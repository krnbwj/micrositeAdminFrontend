import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import Links from "@/pages/links";
import Conversations from "@/pages/conversations";
import Analytics from "@/pages/analytics";
import KnowledgeBase from "@/pages/knowledge-base";
import Login from "@/pages/login";
import { AuthProvider } from "@/context/AuthContext";
import { SidebarProvider } from "@/context/SidebarContext";
import AppLayout from "@/components/layout/AppLayout";
import { useAuth } from "@/hooks/use-auth";

function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { user, isLoading } = useAuth();
  
  if (isLoading) {
    return (
      <div className="h-screen w-full flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  if (!user) {
    window.location.href = "/login";
    return null;
  }
  
  return <Component />;
}

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/">
        <AppLayout>
          <ProtectedRoute component={Dashboard} />
        </AppLayout>
      </Route>
      <Route path="/links">
        <AppLayout>
          <ProtectedRoute component={Links} />
        </AppLayout>
      </Route>
      <Route path="/conversations">
        <AppLayout>
          <ProtectedRoute component={Conversations} />
        </AppLayout>
      </Route>
      <Route path="/analytics">
        <AppLayout>
          <ProtectedRoute component={Analytics} />
        </AppLayout>
      </Route>
      <Route path="/knowledge-base">
        <AppLayout>
          <ProtectedRoute component={KnowledgeBase} />
        </AppLayout>
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <SidebarProvider>
            <Toaster />
            <Router />
          </SidebarProvider>
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
