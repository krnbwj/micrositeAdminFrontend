// This script is loaded when a user visits a proxy link
// It renders a conversation interface for the AI interaction

(function() {
  // Get the link data from the page
  const linkData = window.LINK_DATA || {};
  
  // Generate a random session ID
  const sessionId = Math.random().toString(36).substring(2, 15);
  
  // Create the conversation UI
  function createConversationUI() {
    const styles = `
      body, html {
        margin: 0;
        padding: 0;
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        height: 100%;
        background-color: #f8fafc;
      }
      
      * {
        box-sizing: border-box;
      }
      
      #conversation-root {
        height: 100vh;
        display: flex;
        flex-direction: column;
      }
      
      .header {
        background-color: #4F46E5;
        padding: 1rem;
        color: white;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
      }
      
      .header-title {
        font-size: 1.25rem;
        font-weight: 600;
        display: flex;
        align-items: center;
      }
      
      .header-subtitle {
        font-size: 0.875rem;
        opacity: 0.8;
        margin-top: 0.25rem;
      }
      
      .messages-container {
        flex: 1;
        overflow-y: auto;
        padding: 1rem;
      }
      
      .message {
        display: flex;
        margin-bottom: 1rem;
        animation: fadeIn 0.3s ease-in-out;
      }
      
      .message.user {
        justify-content: flex-end;
      }
      
      .message-avatar {
        width: 2rem;
        height: 2rem;
        border-radius: 50%;
        background-color: #f1f5f9;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 600;
        font-size: 0.75rem;
      }
      
      .message.assistant .message-avatar {
        background-color: #eff6ff;
        color: #3730a3;
      }
      
      .message.user .message-avatar {
        background-color: #f1f5f9;
        color: #475569;
        order: 2;
        margin-left: 0.75rem;
      }
      
      .message-bubble {
        max-width: 80%;
        padding: 0.75rem 1rem;
        border-radius: 0.75rem;
        font-size: 0.875rem;
        line-height: 1.5;
      }
      
      .message.assistant .message-bubble {
        background-color: #eff6ff;
        color: #1e293b;
        margin-left: 0.75rem;
      }
      
      .message.user .message-bubble {
        background-color: #f1f5f9;
        color: #1e293b;
        margin-right: 0.75rem;
        order: 1;
      }
      
      .input-container {
        padding: 1rem;
        border-top: 1px solid #e2e8f0;
        background-color: white;
      }
      
      .input-form {
        display: flex;
        gap: 0.5rem;
      }
      
      .input-textarea {
        flex: 1;
        padding: 0.75rem;
        border: 1px solid #e2e8f0;
        border-radius: 0.375rem;
        font-family: inherit;
        font-size: 0.875rem;
        resize: none;
        outline: none;
        transition: border-color 0.2s;
      }
      
      .input-textarea:focus {
        border-color: #4F46E5;
        box-shadow: 0 0 0 2px rgba(79, 70, 229, 0.1);
      }
      
      .send-button {
        background-color: #4F46E5;
        color: white;
        border: none;
        border-radius: 0.375rem;
        padding: 0 1rem;
        font-weight: 500;
        cursor: pointer;
        transition: background-color 0.2s;
        display: flex;
        align-items: center;
        justify-content: center;
      }
      
      .send-button:hover {
        background-color: #4338ca;
      }
      
      .send-button:disabled {
        background-color: #c7d2fe;
        cursor: not-allowed;
      }
      
      .typing-indicator {
        display: flex;
        align-items: center;
        gap: 0.25rem;
      }
      
      .typing-indicator span {
        width: 0.5rem;
        height: 0.5rem;
        border-radius: 50%;
        background-color: #4F46E5;
        animation: bounce 1.5s infinite ease-in-out;
        opacity: 0.6;
      }
      
      .typing-indicator span:nth-child(2) {
        animation-delay: 0.1s;
      }
      
      .typing-indicator span:nth-child(3) {
        animation-delay: 0.2s;
      }
      
      @keyframes bounce {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-8px); }
      }
      
      @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
      }
    `;
    
    // Create style element
    const styleElement = document.createElement('style');
    styleElement.textContent = styles;
    document.head.appendChild(styleElement);
    
    // Add title and meta tags
    document.title = 'Virtual Assistant';
    
    const metaViewport = document.createElement('meta');
    metaViewport.name = 'viewport';
    metaViewport.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';
    document.head.appendChild(metaViewport);
    
    // Add font
    const fontLink = document.createElement('link');
    fontLink.rel = 'stylesheet';
    fontLink.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap';
    document.head.appendChild(fontLink);
    
    // Create UI structure
    const root = document.getElementById('conversation-root');
    
    if (!root) {
      console.error('Conversation root element not found');
      return;
    }
    
    root.innerHTML = `
      <div class="header">
        <div class="header-title">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-shield" style="margin-right: 0.5rem;">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
          </svg>
          Virtual Assistant
        </div>
        <div class="header-subtitle">How can I help you today?</div>
      </div>
      
      <div class="messages-container" id="messages-container"></div>
      
      <div class="input-container">
        <form class="input-form" id="message-form">
          <textarea 
            class="input-textarea" 
            id="message-input" 
            placeholder="Type your message..." 
            rows="1"
          ></textarea>
          <button type="submit" class="send-button" id="send-button" disabled>
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <line x1="22" y1="2" x2="11" y2="13"></line>
              <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
            </svg>
          </button>
        </form>
      </div>
    `;
  }
  
  // Initialize the conversation
  async function initConversation() {
    createConversationUI();
    
    const messagesContainer = document.getElementById('messages-container');
    const messageForm = document.getElementById('message-form');
    const messageInput = document.getElementById('message-input');
    const sendButton = document.getElementById('send-button');
    
    // Handle input changes
    messageInput.addEventListener('input', () => {
      sendButton.disabled = !messageInput.value.trim();
      
      // Auto resize the textarea
      messageInput.style.height = 'auto';
      messageInput.style.height = (messageInput.scrollHeight) + 'px';
    });
    
    // Create a conversation on the server
    let conversationId;
    try {
      const response = await fetch('/api/conversations', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          linkId: linkData.id,
          sessionId: sessionId,
          visitorIp: 'unknown' // In a real app, the server would determine this
        }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to create conversation');
      }
      
      const data = await response.json();
      conversationId = data.id;
    } catch (error) {
      console.error('Error creating conversation:', error);
      addMessage('assistant', 'Sorry, I encountered an error. Please try again later or refresh the page.');
      return;
    }
    
    // Add initial greeting
    addMessage('assistant', 'Hi there! 👋 How can I help you today?');
    
    // Handle form submission
    messageForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const message = messageInput.value.trim();
      if (!message) return;
      
      // Clear input
      messageInput.value = '';
      messageInput.style.height = 'auto';
      sendButton.disabled = true;
      
      // Add user message to UI
      addMessage('user', message);
      
      // Show typing indicator
      showTypingIndicator();
      
      try {
        // Send message to server
        const response = await fetch('/api/messages', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            conversationId,
            content: message,
            role: 'user'
          }),
        });
        
        if (!response.ok) {
          throw new Error('Failed to send message');
        }
        
        const data = await response.json();
        
        // Hide typing indicator
        hideTypingIndicator();
        
        // Add AI response
        addMessage('assistant', data.aiMessage.content);
        
        // If this is transactional or navigational intent, redirect after a delay
        if (data.intent === 'NAVIGATIONAL' || data.intent === 'TRANSACTIONAL') {
          setTimeout(() => {
            redirectToTarget();
          }, 3000);
        }
      } catch (error) {
        console.error('Error sending message:', error);
        hideTypingIndicator();
        addMessage('assistant', 'Sorry, I encountered an error. Please try again.');
      }
    });
  }
  
  function addMessage(role, content) {
    const messagesContainer = document.getElementById('messages-container');
    
    const messageElement = document.createElement('div');
    messageElement.className = `message ${role}`;
    
    messageElement.innerHTML = `
      <div class="message-avatar">${role === 'assistant' ? 'AI' : 'You'}</div>
      <div class="message-bubble">${content}</div>
    `;
    
    messagesContainer.appendChild(messageElement);
    
    // Scroll to bottom
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }
  
  function showTypingIndicator() {
    const messagesContainer = document.getElementById('messages-container');
    
    const typingElement = document.createElement('div');
    typingElement.className = 'message assistant';
    typingElement.id = 'typing-indicator-message';
    
    typingElement.innerHTML = `
      <div class="message-avatar">AI</div>
      <div class="message-bubble">
        <div class="typing-indicator">
          <span></span>
          <span></span>
          <span></span>
        </div>
      </div>
    `;
    
    messagesContainer.appendChild(typingElement);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }
  
  function hideTypingIndicator() {
    const typingElement = document.getElementById('typing-indicator-message');
    if (typingElement) {
      typingElement.remove();
    }
  }
  
  function redirectToTarget() {
    if (!linkData.targetUrl) {
      console.error('Target URL not found');
      return;
    }
    
    let redirectUrl = linkData.targetUrl;
    
    // Add UTM parameters if provided
    if (linkData.utmParams) {
      const separator = redirectUrl.includes('?') ? '&' : '?';
      redirectUrl = `${redirectUrl}${separator}${linkData.utmParams}`;
    }
    
    // Add session information
    const separator = redirectUrl.includes('?') ? '&' : '?';
    redirectUrl = `${redirectUrl}${separator}session_id=${sessionId}`;
    
    // Redirect
    window.location.href = redirectUrl;
  }
  
  // Initialize when the page loads
  window.addEventListener('DOMContentLoaded', initConversation);
})();
